#!/usr/bin/env Rscript
# ==============================================================================
# reproduce_figure4_crc_case.R
#
# Reproduces Figure 4 (A–J) of the EVOmicsDB manuscript:
# CRC EV proteomics case study (dataset PXD047810)
#
# Steps:
#   1. Differential analysis (limma)
#   2. Volcano plot, heatmap, PCA
#   3. PPI network
#   4. GO/KEGG enrichment (bar + bubble)
#   5. GSEA
#   6. Single-feature ROC (top 3 proteins)
#   7. SVM panel ROC
#   8. RF panel ROC
#
# Usage:
#   Rscript reproducibility/reproduce_figure4_crc_case.R \
#     --data_dir data_downloaded/ \
#     --output_dir results/figure4/
# ==============================================================================

library(argparse)

parser <- ArgumentParser(description = "Reproduce Figure 4: CRC EV proteomics case study")
parser$add_argument("--data_dir", type = "character", required = TRUE,
                    help = "Directory containing downloaded PXD047810 data files")
parser$add_argument("--output_dir", type = "character", default = "results/figure4/",
                    help = "Output directory for all figure panels")
args <- parser$parse_args()

dir.create(args$output_dir, recursive = TRUE, showWarnings = FALSE)

cat("=== Figure 4: CRC EV Proteomics Case Study ===\n")
cat("Dataset: PXD047810 (40 CRC + 30 controls)\n\n")

# --- Step 1: Differential analysis ---
cat("[1/8] Running differential analysis...\n")
deg_rda <- file.path(args$output_dir, "DEG_PXD047810.rda")
system2("Rscript", c(
  "R/analysis/differential_analysis.R",
  "--counts_file", file.path(args$data_dir, "PXD047810_expression_matrix.tsv"),
  "--output_rda", deg_rda,
  "--output_csv", file.path(args$output_dir, "Fig4_filtered_DEG.csv")
))

# --- Step 2: Volcano plot (Fig 4A) ---
cat("[2/8] Generating volcano plot (Fig 4A)...\n")
system2("Rscript", c(
  "R/visualization/volcano_plot.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4A_volcano.png")
))

# --- Step 3: Heatmap (Fig 4B) ---
cat("[3/8] Generating heatmap (Fig 4B)...\n")
system2("Rscript", c(
  "R/visualization/heatmap.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4B_heatmap.png")
))

# --- Step 4: PCA (Fig 4C) ---
cat("[4/8] Generating PCA (Fig 4C)...\n")
system2("Rscript", c(
  "R/analysis/pca.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4C_pca.png")
))

# --- Step 5: PPI network (Fig 4D) ---
cat("[5/8] Building PPI network (Fig 4D)...\n")
system2("Rscript", c(
  "R/network/ppi.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4D_ppi.png"),
  "--output_csv", file.path(args$output_dir, "Fig4D_ppi_interactions.csv")
))

# --- Step 6: GO/KEGG enrichment (Fig 4E, G) ---
cat("[6/8] Running enrichment analysis (Fig 4E, G)...\n")
enrich_rda <- file.path(args$output_dir, "enrichment_PXD047810.rda")
system2("Rscript", c(
  "R/analysis/enrichment_analysis.R",
  "--input_rda", deg_rda,
  "--output_rda", enrich_rda,
  "--is_mrna", "TRUE"
))

# --- Step 7: GSEA (Fig 4F) ---
cat("[7/8] Running GSEA (Fig 4F)...\n")
system2("Rscript", c(
  "R/analysis/gsea.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4F_gsea.png"),
  "--output_csv", file.path(args$output_dir, "Fig4F_gsea_results.csv")
))

# --- Step 8: ROC analyses (Fig 4H–J) ---
cat("[8/8] Running ROC analyses (Fig 4H–J)...\n")
# Single-feature ROC (Fig 4H)
system2("Rscript", c(
  "R/biomarker/roc.R",
  "--input_rda", deg_rda,
  "--output_png", file.path(args$output_dir, "Fig4H_roc_single.png"),
  "--output_csv", file.path(args$output_dir, "Fig4H_roc_single.csv"),
  "--custom_gene", "MMP14", "FAP", "ENPEP"
))

# SVM panel (Fig 4I)
system2("Rscript", c(
  "R/biomarker/roc_svm.R",
  "--input_rda", deg_rda,
  "--output_csv", file.path(args$output_dir, "Fig4I_svm_features.csv")
))

# RF panel (Fig 4J)
system2("Rscript", c(
  "R/biomarker/roc_rf.R",
  "--input_rda", deg_rda,
  "--output_csv", file.path(args$output_dir, "Fig4J_rf_features.csv")
))

cat("\n=== Figure 4 reproduction complete ===\n")
cat("Outputs saved to:", args$output_dir, "\n")
