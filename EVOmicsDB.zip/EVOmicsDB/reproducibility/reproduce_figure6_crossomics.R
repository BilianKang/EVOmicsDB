#!/usr/bin/env Rscript
# ==============================================================================
# reproduce_figure6_crossomics.R
#
# Reproduces Figure 6 (A–D): Cross-omics integration
#   A: mRNA–miRNA cross-layer correlation (GSE255775 vs GSE220445)
#   B: miRNA–mRNA regulatory network
#   C: KEGG pathway network (mRNA GSE255775 + Protein PXD047810)
#   D: GO integrated network (mRNA + Protein)
#
# Usage:
#   Rscript reproducibility/reproduce_figure6_crossomics.R \
#     --data_dir data_downloaded/ \
#     --output_dir results/figure6/
# ==============================================================================

library(argparse)

parser <- ArgumentParser(description = "Reproduce Figure 6: Cross-omics integration")
parser$add_argument("--data_dir", type = "character", required = TRUE,
                    help = "Directory containing downloaded dataset files")
parser$add_argument("--output_dir", type = "character", default = "results/figure6/",
                    help = "Output directory")
args <- parser$parse_args()

dir.create(args$output_dir, recursive = TRUE, showWarnings = FALSE)

cat("=== Figure 6: Cross-Omics Integration ===\n")

# --- Fig 6A: Cross-omics trend analysis ---
cat("[Fig6A] Cross-omics trend analysis (mRNA vs miRNA)...\n")
system2("Rscript", c(
  "R/cross_omics/cross_omics_trend_analysis.R",
  "--input_file1", file.path(args$data_dir, "GSE255775_DA_result.txt"),
  "--input_file2", file.path(args$data_dir, "GSE220445_DA_result.txt"),
  "--omics1_name", "mRNA_GSE255775",
  "--omics2_name", "miRNA_GSE220445",
  "--output_png", file.path(args$output_dir, "Fig6A_cross_omics_trend.png")
))

# --- Fig 6B: miRNA–mRNA regulatory network ---
cat("[Fig6B] miRNA-mRNA regulatory network...\n")
system2("Rscript", c(
  "R/network/regulatory_network.R",
  "--mirna_dataset", file.path(args$data_dir, "GSE220445_DA_result.txt"),
  "--target_dataset", file.path(args$data_dir, "GSE255775_DA_result.txt"),
  "--target_group", "mRNA",
  "--output_html", file.path(args$output_dir, "Fig6B_regulatory_network.html"),
  "--output_csv", file.path(args$output_dir, "Fig6B_regulatory_network.csv")
))

# --- Fig 6C: KEGG pathway network (mRNA + Protein) ---
cat("[Fig6C] KEGG joint pathway network...\n")
system2("Rscript", c(
  "R/network/kegg_network.R",
  "--input_file1", file.path(args$data_dir, "GSE255775_DA_result.txt"),
  "--input_file2", file.path(args$data_dir, "PXD047810_DA_result.txt"),
  "--type1", "mRNA", "--type2", "Protein",
  "--output_html", file.path(args$output_dir, "Fig6C_kegg_network.html"),
  "--output_csv", file.path(args$output_dir, "Fig6C_kegg_network.csv")
))

# --- Fig 6D: GO integrated network (mRNA + Protein) ---
cat("[Fig6D] GO integrated network...\n")
system2("Rscript", c(
  "R/network/go_network.R",
  "--input_file1", file.path(args$data_dir, "GSE255775_DA_result.txt"),
  "--input_file2", file.path(args$data_dir, "PXD047810_DA_result.txt"),
  "--output_html", file.path(args$output_dir, "Fig6D_go_network.html"),
  "--output_csv", file.path(args$output_dir, "Fig6D_go_network.csv")
))

cat("\n=== Figure 6 reproduction complete ===\n")
cat("Outputs saved to:", args$output_dir, "\n")
