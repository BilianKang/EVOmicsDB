# Reproducing Manuscript Figures

This directory contains wrapper scripts that reproduce the main analytical results presented in the EVOmicsDB manuscript. These scripts are wrapper scripts that call the command-line analysis modules in this repository with the specific parameters and datasets used in the paper.

## Prerequisites

1. **Install R dependencies** as described in the main [README](../README.md).
2. **Download the required datasets** from [EVOmicsDB](https://EVOmicsDB.com) or their original repositories. Accession numbers are listed in [`metadata/EVOmicsDB_manifest.json`](../metadata/EVOmicsDB_manifest.json).
3. Place downloaded data files in a local `data_downloaded/` directory (not tracked by git).

## Scripts

| Script | Figure | Datasets Required | Inputs | Outputs |
|--------|--------|-------------------|--------|---------|
| `reproduce_figure4_crc_case.R` | Figure 4A–J | PXD047810 (CRC EV proteomics) | PXD047810 counts matrix + sample metadata | Volcano plot, heatmap, PCA, PPI network, GO/KEGG enrichment, GSEA, single-feature ROC, RF panel ROC, SVM panel ROC (PNG/PDF + CSV) |
| `reproduce_figure5_hsp90aa1.R` | Figure 5A–G | 16 EV proteomic datasets (see manifest) | Per-dataset counts matrices + sample metadata | HSP90AA1 cross-dataset box plot, per-cohort ROC curves (PNG/PDF + CSV) |
| `reproduce_figure6_crossomics.R` | Figure 6A–D | GSE255775, GSE220445, PXD047810 | DE result files from each dataset | Cross-omics trend scatter, miRNA–mRNA regulatory network, KEGG pathway network, GO integrated network (PNG/PDF + HTML + CSV) |

## Running

```bash
# From the repository root:
Rscript reproducibility/reproduce_figure4_crc_case.R --data_dir data_downloaded/ --output_dir results/figure4/
Rscript reproducibility/reproduce_figure5_hsp90aa1.R --data_dir data_downloaded/ --output_dir results/figure5/
Rscript reproducibility/reproduce_figure6_crossomics.R --data_dir data_downloaded/ --output_dir results/figure6/
```

## Expected Outputs

Each script creates its output directory and generates PNG/PDF plots and CSV result tables corresponding to the respective manuscript figure panels. Exact numerical results may vary slightly depending on R version and package versions due to stochastic elements in methods like Random Forest.
