#!/usr/bin/env Rscript
# ==============================================================================
# reproduce_figure5_hsp90aa1.R
#
# Reproduces Figure 5 (A–G): Pan-cancer HSP90AA1 cross-dataset evaluation
#
# This script performs single-feature ROC analysis for HSP90AA1 across
# multiple EV proteomic datasets to demonstrate context-dependent biomarker
# performance.
#
# Usage:
#   Rscript reproducibility/reproduce_figure5_hsp90aa1.R \
#     --data_dir data_downloaded/ \
#     --output_dir results/figure5/
# ==============================================================================

library(argparse)

parser <- ArgumentParser(description = "Reproduce Figure 5: Pan-cancer HSP90AA1 evaluation")
parser$add_argument("--data_dir", type = "character", required = TRUE,
                    help = "Directory containing downloaded proteomic dataset files")
parser$add_argument("--output_dir", type = "character", default = "results/figure5/",
                    help = "Output directory")
args <- parser$parse_args()

dir.create(args$output_dir, recursive = TRUE, showWarnings = FALSE)

cat("=== Figure 5: Pan-Cancer HSP90AA1 Evaluation ===\n")

# Datasets used in Figure 5B-G
datasets <- list(
  list(id = "PXD047810", cancer = "CRC",  panel = "Fig5B"),
  list(id = "PXD042422", cancer = "NB",   panel = "Fig5C"),
  list(id = "PXD046511", cancer = "GBM",  panel = "Fig5D"),
  list(id = "PXD041118", cancer = "BLCA", panel = "Fig5E"),
  list(id = "PXD040756", cancer = "HCC",  panel = "Fig5F"),
  list(id = "PXD067299", cancer = "MB",   panel = "Fig5G")
)

for (ds in datasets) {
  cat(sprintf("[%s] ROC for HSP90AA1 in %s (%s)...\n", ds$panel, ds$cancer, ds$id))

  # Step 1: DE analysis
  deg_rda <- file.path(args$output_dir, paste0("DEG_", ds$id, ".rda"))
  data_file <- file.path(args$data_dir, paste0(ds$id, "_expression_matrix.tsv"))

  if (!file.exists(data_file)) {
    cat(sprintf("  WARNING: %s not found, skipping.\n", data_file))
    next
  }

  system2("Rscript", c(
    "R/analysis/differential_analysis.R",
    "--counts_file", data_file,
    "--output_rda", deg_rda
  ))

  # Step 2: ROC for HSP90AA1
  system2("Rscript", c(
    "R/biomarker/roc.R",
    "--input_rda", deg_rda,
    "--output_png", file.path(args$output_dir, paste0(ds$panel, "_HSP90AA1_", ds$cancer, ".png")),
    "--output_csv", file.path(args$output_dir, paste0(ds$panel, "_HSP90AA1_", ds$cancer, ".csv")),
    "--custom_gene", "HSP90AA1"
  ))
}

cat("\n=== Figure 5 reproduction complete ===\n")
cat("Outputs saved to:", args$output_dir, "\n")
