# EVOmicsDB Manifest Field Definitions

`EVOmicsDB_manifest.json` contains metadata for all 102 curated datasets in EVOmicsDB v1.0.

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `id` | integer | Internal dataset ID | 1 |
| `disease_name` | string | Cancer type | "Colorectal cancer" |
| `pmid` | integer | PubMed ID of the source study | 32287312 |
| `contributors` | string | First/corresponding author of original study | "Blanca Elena Castro-Magdonel" |
| `quantity` | integer | Total number of samples (case + control) | 24 |
| `detection_methods` | string | Molecular profiling platform | "miRNA microarrays" |
| `ev_isolation_methods` | string | EV isolation method | "Ultracentrifugation" |
| `detailed_description` | string | Sample composition and clinical annotation summary | "12 patients and 12 healthy controls; Including clinical information" |
| `omics_type` | string | Omics domain: Transcriptomics, Proteomics, Metabolomics, or Targeted Proteomics | "Transcriptomics" |
| `rna_molecules` | string | RNA subtype if applicable (mRNA, miRNA, lncRNA), empty for non-RNA | "miRNA" |
| `samples_type` | string | Biofluid or specimen source | "Plasma" |
| `cancer_site` | string | Anatomical cancer site | "Eye" |
| `raw_data` | string | Whether raw data is available ("Yes" / "No") | "No" |
| `dataset` | string | Public accession number | "GSE141208" |
| `data_file` | string | Internal path to quantitative matrix | "db/dataset/NO01_GSE141208_c..." |
| `sample_metadata_file` | string | Internal path to sample metadata | (path string) |
| `quantification_method` | string | Quantification or normalization method applied | (method string) |

## Notes

- All datasets are derived from human clinical specimens with defined cancer and control groups.
- Cell-line and animal-model datasets are excluded.
- The `data_file` and `sample_metadata_file` fields reference internal EVOmicsDB paths. Curated matrices are downloadable from [https://EVOmicsDB.com](https://EVOmicsDB.com).
