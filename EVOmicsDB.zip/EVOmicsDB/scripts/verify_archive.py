#!/usr/bin/env python3
"""Verify every archived file against SHA256SUMS.txt, without external dependencies."""
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parents[1];errors=[];count=0
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
 expected,name=line.split('  ',1);f=root/name
 if not f.is_file():errors.append('Missing: '+name);continue
 h=hashlib.sha256()
 with f.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 if h.hexdigest()!=expected:errors.append('Mismatch: '+name)
 count+=1
print('\n'.join(errors) if errors else f'PASS: {count} files match SHA-256.')
sys.exit(bool(errors))
