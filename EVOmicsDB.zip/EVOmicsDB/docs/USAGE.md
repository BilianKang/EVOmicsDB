# Usage Guide

## Data Flow

```
Expression matrix (.tsv)
       │
       ▼
differential_analysis.R  →  DEG.rda
       │
       ├──► volcano_plot.R        → PNG
       ├──► heatmap.R             → PNG
       ├──► pca.R                 → PNG
       ├──► enrichment_analysis.R → enrichment.rda → go_bar_plot.R / kegg_bubble_plot.R
       ├──► gsea.R                → PNG, CSV
       ├──► ppi.R                 → PNG, CSV
       ├──► roc.R                 → PNG, CSV
       ├──► roc_rf.R / roc_svm.R → CSV (selected features)
       └──► roc_logistic.R        → PNG, CSV (panel ROC)

Cross-omics (two DE result files):
       ├──► cross_omics_trend_analysis.R → PNG, CSV
       ├──► regulatory_network.R         → HTML, CSV
       ├──► lncrna_target_network.R      → HTML, CSV
       ├──► kegg_network.R               → HTML, CSV
       └──► go_network.R                 → HTML, CSV
```

## Input Formats

### Expression matrix (for `differential_analysis.R`)

Tab-delimited. First column = feature IDs, remaining columns = samples. Values: raw counts or normalized intensities (auto-detected).

```
Feature    CTRL_1    CTRL_2    CASE_1    CASE_2
GENE_A     8.234     7.891     10.445    11.023
GENE_B     5.112     5.334     5.201     5.089
```

### DE result files (for cross-omics and network scripts)

Tab-delimited. Must include columns: feature ID, `logFC`, `P.Value` or `adj.P.Val`.

## Output Formats

- **PNG/PDF:** Publication-quality plots (dimensions configurable via `--width`, `--height`)
- **CSV:** Tabular results (DE genes, ROC coordinates, network edges, enrichment terms)
- **HTML:** Interactive network visualizations (visNetwork)
- **RDA:** R data objects for chaining analyses

## Parameter Reference

Every script supports `--help`:

```bash
Rscript R/analysis/differential_analysis.R --help
Rscript R/biomarker/roc.R --help
Rscript R/network/kegg_network.R --help
```

## Figure-to-Script Mapping

| Figure Panel | Script(s) | Input |
|-------------|-----------|-------|
| Fig 4A | `volcano_plot.R` | PXD047810 DEG.rda |
| Fig 4B | `heatmap.R` | PXD047810 DEG.rda |
| Fig 4C | `pca.R` | PXD047810 DEG.rda |
| Fig 4D | `ppi.R` | PXD047810 DEG.rda |
| Fig 4E | `go_bar_plot.R` | PXD047810 enrichment.rda |
| Fig 4F | `gsea.R` | PXD047810 DEG.rda |
| Fig 4G | `kegg_bubble_plot.R` | PXD047810 enrichment.rda |
| Fig 4H | `roc.R --custom_gene MMP14 FAP ENPEP` | PXD047810 DEG.rda |
| Fig 4I | `roc_svm.R` → `roc_logistic.R` | PXD047810 DEG.rda |
| Fig 4J | `roc_rf.R` → `roc_logistic.R` | PXD047810 DEG.rda |
| Fig 5B–G | `roc.R --custom_gene HSP90AA1` | Per-dataset DEG.rda |
| Fig 6A | `cross_omics_trend_analysis.R` | GSE255775 + GSE220445 DE results |
| Fig 6B | `regulatory_network.R` | GSE220445 + GSE255775 DE results |
| Fig 6C | `kegg_network.R` | GSE255775 + PXD047810 DE results |
| Fig 6D | `go_network.R` | GSE255775 + PXD047810 DE results |
