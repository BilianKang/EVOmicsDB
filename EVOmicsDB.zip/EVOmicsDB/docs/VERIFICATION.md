# Verification of the standalone distribution

Date: 23 September 2026. Analytical version: 1.1.0. Distribution: `github-standalone-20260923`.

The following checks were performed on the reorganized files using Python 3.14 and R 4.5.2 in the available local environment:

| Check | Outcome |
|---|---|
| Core scientific source identity | All 27 R files and both analysis configuration files are byte-identical to the reviewed original ZIP |
| Retained file identities | All 79 retained/copied file mappings match their recorded current SHA256 |
| Python/R syntax | 8 Python files and 35 R files parsed successfully |
| Configuration/registry | 110 unique entry IDs agree; all configurations produce valid R arguments; ID12 retains log2 input with no second transformation |
| Retained Figure 1d counts | All six categories and their recorded audit counts agree |
| Identifier namespace regression | Passed |
| miRNA resolution regression | Passed |
| GO classification regression | Passed |
| External snapshot restoration | Synthetic checks passed for missing inputs, mismatched hashes, validation before copying and preservation of existing files |
| Artificial demo | Differential analysis, volcano and named-marker ROC completed successfully through the reorganized runners |
| Demo dependency check | All listed packages present |
| Figure dependency check | `svglite` absent in the available local R library; complete redraws were not executed for this distribution |

The included figure inputs are copied unchanged from the identified source archives. Their presence resolves the previous missing Figure 5 input directory; it does not establish that all plotting dependencies are installed.

The checks do not certify a clean-environment installation, public input availability, all 110 real-data reruns, complete manuscript reconstruction or production website deployment. Earlier scientific validation reports remain in the paired full archive and are not represented as new executions.

To repeat the bounded checks:

```sh
python3 scripts/verify_archive.py
python3 tests/validate_package.py
Rscript environment/check_packages.R demo
python3 scripts/run_demo.py --out outputs/new_demo
```

`SHA256SUMS.txt` identifies the distributed files; `docs/provenance.json` additionally records their original archive identities and all path-only adaptations. Generated test outputs are excluded from the public package.
