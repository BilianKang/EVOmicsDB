# Availability and Implementation

## Web Platform

EVOmicsDB is freely available at [https://EVOmicsDB.com](https://EVOmicsDB.com) via HTTPS without mandatory registration. The platform supports all major browsers and provides built-in test datasets for immediate exploration. Help documentation and a step-by-step tutorial are available on the website.

## This Repository

This GitHub repository contains the core analytical workflows, reproducibility scripts, and dataset metadata manifest associated with EVOmicsDB. It does not include the production web application source code. The production web platform is deployed and maintained separately.

### What is included

- R scripts implementing differential analysis, functional enrichment, biomarker evaluation, visualization, network construction, and cross-omics integration
- Dataset metadata manifest (`metadata/EVOmicsDB_manifest.json`) covering all 102 curated datasets
- Reproducibility wrapper scripts mapping to manuscript figures
- Minimal example data for verifying script execution

### What is not included

- Web application source code (the production web platform is deployed and maintained separately)
- Full curated expression matrices (downloadable from [EVOmicsDB](https://EVOmicsDB.com))
- Raw sequencing or mass spectrometry data (available from original repositories; accession numbers in the manifest)

## Data Access

Curated analysis-ready matrices with harmonized clinical annotations can be downloaded from [https://EVOmicsDB.com](https://EVOmicsDB.com). Original source data are available from their respective public repositories (GEO, PRIDE, etc.) under the accession numbers listed in `metadata/EVOmicsDB_manifest.json`.

## Maintenance

The authors commit to maintaining the EVOmicsDB web service for at least three years following publication. This code repository will remain publicly accessible on GitHub.

## Versioning

- **EVOmicsDB v1.0:** Data freeze December 2025. 102 datasets, 4,097 samples, 16 cancer types.
- **Repository:** Tagged releases correspond to manuscript versions.
