#!/usr/bin/env Rscript

library(FactoMineR)
library(factoextra)
library(argparse)

parser <- ArgumentParser(description="Perform PCA analysis on gene expression data.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to save the PCA plot (e.g., pca_plot.png).")
parser$add_argument("--output_csv", type="character", required=TRUE, help="Path to save the PCA plot data as a CSV file (e.g., pca_data.csv).")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., pca_plot.pdf).")
parser$add_argument("--main_title", type="character", default="PCA Plot", help="Title for the plot (default: PCA Plot).")
parser$add_argument("--x_axis_title", type="character", default="PC1", help="Title for the x-axis. (default: PC1).")
parser$add_argument("--y_axis_title", type="character", default="PC2", help="Title for the y-axis. (default: PC2).")
parser$add_argument("--axis_title_size", type="numeric", default=10, help="Font size of the axis titles. (default: 10).")
parser$add_argument("--axis_text_size", type="numeric", default=8, help="Font size of the axis labels. (default: 8).")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Whether to show the legend (default: TRUE).")
parser$add_argument("--legend_title", type="character", default="Expression", help="Title of the legend (default: Expression).")
parser$add_argument("--legend_title_size", type="numeric", default=10, help="Font size of the legend (default: 10).")
parser$add_argument("--legend_text_size", type="numeric", default=8, help="Font size of the legend labels. (default: 8).")
parser$add_argument("--legend_position", type="character", default="right", help="Position of the legend (default: right).")
parser$add_argument("--normal_fill_color", type="character", default="#00AFBB", help="Colors for top annotations (default: #00AFBB).")
parser$add_argument("--tumor_fill_color", type="character", default="#B40426", help="Colors for bottom annotations (default: #B40426).")
parser$add_argument("--size", type="numeric", default=1.8, help="Size of the points in the plot.")
parser$add_argument("--opacity", type="numeric", default=0.8, help="Opacity of the points in the plot.")
parser$add_argument("--shape", type="numeric", default=21, help="Shape of the points in the plot.")
parser$add_argument("--is_show_border", type="logical", default=TRUE, help="Whether to show the border of the points in the plot.")
parser$add_argument("--width", type="numeric", default=800, help="Width of the output image.")
parser$add_argument("--height", type="numeric", default=600, help="Height of the output image.")
parser$add_argument("--font_size", type="numeric", default=7, help="Font size for the plot text.")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

dat <- as.data.frame(t(exp))
dat.pca <- PCA(dat, graph = FALSE)
group_list <- ifelse(substr(colnames(exp), 1, 1) == "N", "normal", "tumor")
group_list <- factor(group_list, levels = c("normal", "tumor"))
p <- fviz_pca_ind(
  dat.pca,
  geom.ind = "point",
  col.ind = group_list,
  palette = c("normal" = args$normal_fill_color, "tumor" = args$tumor_fill_color),
  addEllipses = TRUE,
  legend.title = args$legend_title,
  pointshape = args$shape,
  pointsize = args$size,
  alpha.ind = args$opacity,
  stroke = if (args$is_show_border) 0.5 else 0
) +
  labs(title = args$main_title, x = args$x_axis_title, y = args$y_axis_title) +
  theme(
    text = element_text(size = args$font_size, family = "sans"), # Base font size
    axis.title = element_text(size = args$axis_title_size),
    axis.text = element_text(size = args$axis_text_size),
    legend.title = element_text(size = args$legend_title_size),
    legend.text = element_text(size = args$legend_text_size),
    legend.position = if (args$is_show_legend) args$legend_position else "none",
  )

ggsave(
  filename = args$output_png,
  plot = p,
  width = args$width,
  height = args$height,
  units = "px",
  device = "png",
  dpi = 300
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = p,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

pca_df <- as.data.frame(dat.pca$ind$coord)
write.csv(pca_df, file = args$output_csv, row.names = TRUE, quote = TRUE)
