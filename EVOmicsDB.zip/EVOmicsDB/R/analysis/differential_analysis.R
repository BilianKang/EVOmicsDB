#!/usr/bin/env Rscript
library(limma)
library(tidyverse)
library(edgeR)
library(argparse)
library(impute)
library(imputeLCMD)

## =========================================================
## Utility functions
## =========================================================

## Heuristically check whether a matrix looks log2-scaled (with small-matrix adaptation)
is_log2_like <- function(mat) {
  # Ensure input is a matrix
  if (is.data.frame(mat)) {
    mat <- as.matrix(mat)
  }
  x <- as.numeric(mat)
  x <- x[is.finite(x)]
  n_eff <- length(x)
  if (n_eff < max(30, 10 * ncol(mat))) return(FALSE)
  qs <- stats::quantile(x, probs = c(0.01, 0.5, 0.99), na.rm = TRUE)
  (qs[[3]] <= 50) && (qs[[1]] >= -20)
}

## =========================================================
## 1. Parse command-line arguments
## =========================================================
parser <- ArgumentParser(
  description = "Perform limma-voom / limma-trend differential expression analysis."
)
parser$add_argument("--counts_file", type = "character", required = TRUE,
                    help = "Path to the input counts/intensity table (rows = features, columns = samples).")
parser$add_argument("--output_rda", type = "character", required = TRUE,
                    help = "Path to save the DEG result object (e.g., DEG.rda).")
parser$add_argument("--is_output_csv", type = "logical", default = TRUE,
                    help = "Whether to output the filtered DE genes/features as a CSV file. Default = TRUE.")
parser$add_argument("--output_csv", type = "character", required = FALSE,
                    help = "Path to save the filtered DE genes/features as a CSV file (e.g., filtered_DEG.csv).")
parser$add_argument("--is_raw_data", type = "logical", default = TRUE,
                    help = "For transcriptomics: TRUE = raw counts; FALSE = already normalized / log-transformed.")
parser$add_argument("--is_transcriptomics", type = "logical", required = FALSE, default = TRUE,
                    help = "If TRUE, the input table is transcriptomics data; if FALSE, it is proteomics/metabolomics.")
parser$add_argument("--is_use_padj", type = "logical", required = FALSE, default = TRUE,
                    help = "Whether to use adjusted P value (FDR) for filtering.")
parser$add_argument("--log2fc", type = "numeric", required = FALSE, default = 1,
                    help = "Absolute log2 fold-change threshold for filtering.")
parser$add_argument("--pvalue", type = "numeric", required = FALSE, default = 0.05,
                    help = "P-value / FDR threshold for filtering (depending on is_use_padj).")
parser$add_argument("--quantification_method",
                    type = "character",
                    required = FALSE,
                    default = "other",
                    help = paste("For non-transcriptomics data specify platform type:",
                                 "LFQ / TMT / iTRAQ / DIA / metabolomics / other"))

args <- parser$parse_args()

quantification_method <- tolower(args$quantification_method)

## =========================================================
## 2. Read expression/abundance matrix
## =========================================================
exp <- read.table(
  args$counts_file,
  sep = "\t",
  row.names = 1,
  check.names = FALSE,
  stringsAsFactors = FALSE,
  header = TRUE
)

## =========================================================
## 3. Branch by data type
##    - Non-transcriptomics: choose imputation + normalization by quantification_method
##    - Transcriptomics (already normalized): mean-expression + detection-rate filtering (ensure log2-like scale)
##    - Transcriptomics (raw counts): handled later via filterByExpr
## =========================================================
if (!args$is_transcriptomics) {
  ## ================= Non-transcriptomics (proteomics / metabolomics) =================
  exp <- as.matrix(exp)
  storage.mode(exp) <- "numeric"

  ## --- 1) Filter low-intensity features and excessive missingness ---
  exp <- exp[rowMeans(exp, na.rm = TRUE) > 0, , drop = FALSE]

  max_na_row <- 0.3
  row_na_ratio <- rowSums(is.na(exp)) / ncol(exp)
  exp <- exp[row_na_ratio <= max_na_row, , drop = FALSE]

  max_na_col <- 0.3
  col_na_ratio <- colSums(is.na(exp)) / nrow(exp)
  exp <- exp[, col_na_ratio <= max_na_col, drop = FALSE]

  ## --- 2) Apply log2(x+1) only if not log2-like ---
  if (!is_log2_like(exp)) {
    message("Non-transcriptomics matrix does not look log2-like; applying log2(x+1).")
    exp <- log2(exp + 1)
  }

  ## --- 3) Imputation + normalization by quantification_method ---
  if (quantification_method == "lfq") {
    message("quantification_method = LFQ: using MinProb imputation, no further global normalization.")
    exp <- imputeLCMD::impute.MinProb(exp, q = 0.01, tune.sigma = 0.3)

  } else if (quantification_method %in% c("tmt", "itraq")) {
    message("quantification_method = TMT/iTRAQ: minimal imputation + median normalization.")
    na_prop <- mean(is.na(exp))
    if (na_prop > 0.02) {
      if (na_prop > 0.05) {
        warning("TMT/iTRAQ data has >5% missing values; consider more careful handling.")
      }
      set.seed(123)
      exp <- impute::impute.knn(exp)$data
    }
    ## median normalization
    exp <- limma::normalizeBetweenArrays(exp, method = "median")

  } else if (quantification_method == "dia") {
    message("quantification_method = DIA: KNN imputation + quantile normalization.")
    set.seed(123)
    exp <- impute::impute.knn(exp)$data
    exp <- limma::normalizeBetweenArrays(exp, method = "quantile")

  } else if (quantification_method == "lcms relative intensity") {
    message("quantification_method = lcms relative intensity: MinDet (MNAR) imputation + quantile normalization.")
    exp <- imputeLCMD::impute.MinDet(exp, q = 0.01)
    exp <- limma::normalizeBetweenArrays(exp, method = "quantile")

  } else {
    message("quantification_method = other: using generic KNN imputation + quantile normalization. ",
            "You may want to double-check whether this is appropriate for your platform.")
    set.seed(123)
    exp <- impute::impute.knn(exp)$data
    exp <- limma::normalizeBetweenArrays(exp, method = "quantile")
  }

} else {
  ## ================= Transcriptomics =================
  if (!args$is_raw_data) {
    if (!is_log2_like(exp)) {
      message("Input transcriptomics matrix does not look log2-like; applying log2(x+1).")
      exp <- log2(as.matrix(exp) + 1)
    }

    min_mean      <- 1
    min_prop      <- 0.5
    detect_cutoff <- 0

    mean_expr   <- rowMeans(exp, na.rm = TRUE)
    prop_detect <- rowMeans(exp > detect_cutoff, na.rm = TRUE)
    keep <- (mean_expr > min_mean) & (prop_detect >= min_prop)
    exp  <- exp[keep, , drop = FALSE]
  }
}

## =========================================================
## 4. Infer group labels and build the design matrix
## =========================================================
grp_guess <- ifelse(substr(colnames(exp), 1, 1) == "N", "normal", "tumor")
group_list <- factor(grp_guess, levels = c("normal", "tumor"))

tab <- table(group_list, useNA = "ifany")
if (any(is.na(group_list)) || length(tab) < 2) {
  stop("Group inference failed: cannot form both 'normal' and 'tumor'. Please check sample names.")
}
if (min(tab) < 2) {
  warning("Very small group size detected: ",
          paste(names(tab), tab, collapse = ", "),
          ". Differential results may be unreliable.")
}

design <- model.matrix(~ group_list)

## =========================================================
## 5. Choose voom (raw counts) or use exp directly (normalized/non-transcriptomics)
## =========================================================
if (args$is_transcriptomics && args$is_raw_data) {
  ## ===== Transcriptomics + raw counts: filterByExpr + TMM + voom =====
  exp <- as.matrix(exp)
  storage.mode(exp) <- "numeric"

  if (any(exp < 0, na.rm = TRUE)) stop("Counts matrix contains negative values.")
  if (any(abs(exp - round(exp)) > 1e-6, na.rm = TRUE)) {
    warning("Counts matrix has non-integer values; rounding to nearest integer.")
    exp <- round(exp)
  }

  dge <- DGEList(counts = exp, group = group_list)
  keep <- filterByExpr(dge, group = group_list)
  dge  <- dge[keep, , keep.lib.sizes = FALSE]
  dge <- calcNormFactors(dge)
  v   <- voom(dge, design, plot = FALSE)
} else {
  ## Non-transcriptomics or already-normalized transcriptomics: use exp directly in limma
  v <- exp
}

## =========================================================
## 6. Fit the linear model and perform differential analysis
## =========================================================
fit <- lmFit(v, design)
if (args$is_transcriptomics) {
  fit <- eBayes(fit, robust = TRUE)
  deg <- topTable(fit, coef = 2, number = Inf, adjust.method = "fdr")
} else {
  fit <- eBayes(fit, trend = TRUE, robust = TRUE)
  deg <- topTable(fit, coef = 2, number = Inf, adjust.method = "fdr")
}

## =========================================================
## 7. Flag extreme logFC instead of removing
## =========================================================
deg$flag_extreme_logFC <- abs(deg$logFC) > 10

## =========================================================
## 8. Save RDA (expression matrix + full DE results)
## =========================================================
save(exp, deg, file = args$output_rda)

## =========================================================
## 9. Optional: export a threshold-filtered CSV
## =========================================================
if (args$is_output_csv) {
  if (args$is_use_padj) {
    filtered_deg <- as.data.frame(deg) %>%
      arrange(adj.P.Val) %>%
      dplyr::filter(
        abs(logFC) > as.numeric(args$log2fc),
        adj.P.Val   < as.numeric(args$pvalue)
      )
  } else {
    filtered_deg <- as.data.frame(deg) %>%
      arrange(P.Value) %>%
      dplyr::filter(
        abs(logFC) > as.numeric(args$log2fc),
        P.Value    < as.numeric(args$pvalue)
      )
  }
  write.csv(
    filtered_deg,
    file = args$output_csv,
    row.names = TRUE,
    quote = TRUE
  )
} else {
  message("No CSV output specified. Skipping CSV export.")
}
