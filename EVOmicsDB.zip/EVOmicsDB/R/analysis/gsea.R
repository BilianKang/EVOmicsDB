#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(tidyverse)
  library(org.Hs.eg.db)
  library(clusterProfiler)
  library(msigdbr)
  library(patchwork)
  library(enrichplot)
  library(argparse)
  library(AnnotationDbi)
})

# =========================================================
# 1) Command-line arguments
#    NOTE: is_use_padj / log2fc_threshold / pvalue_threshold are kept only for
#    backward compatibility with the web pipeline. Standard GSEA does NOT
#    pre-filter significant genes.
# =========================================================
parser <- ArgumentParser(description = "Generate an overlay plot for GSEA (standard: rank all genes).")
parser$add_argument("--input_rda", type = "character", required = TRUE,
                    help = "Path to the input RDA containing objects 'exp' and 'deg'.")
parser$add_argument("--output_png", type = "character", required = TRUE,
                    help = "Path to the output PNG file.")
parser$add_argument("--output_csv", type = "character", required = TRUE,
                    help = "Path to the output CSV file for GSEA results.")
parser$add_argument("--output_pdf", type = "character", default = NULL,
                    help = "Optional path to save the plot as PDF (e.g., plot_name.pdf).")

# Kept for compatibility (NOT used for pre-filtering in standard GSEA)
parser$add_argument("--is_use_padj", type = "logical", default = TRUE,
                    help = "(Compatibility) Not used for pre-filtering in standard GSEA.")
parser$add_argument("--log2fc_threshold", type = "numeric", default = 1,
                    help = "(Compatibility) Not used for pre-filtering in standard GSEA.")
parser$add_argument("--pvalue_threshold", type = "numeric", default = 0.05,
                    help = "(Compatibility) Not used for pre-filtering in standard GSEA.")

# Plot settings
parser$add_argument("--top_n", type = "integer", default = 10,
                    help = "Number of top pathways to display. Default is 10.")
parser$add_argument("--main_title", type = "character", default = "Enrichment Plot",
                    help = "Main title for the plot.")
parser$add_argument("--x_axis_title", type = "character", default = "Log2 Fold Change",
                    help = "Title for the X-axis.")
parser$add_argument("--y_axis_title", type = "character", default = "Adjusted P-value",
                    help = "Title for the Y-axis.")
parser$add_argument("--main_title_size", type = "integer", default = 16,
                    help = "Font size for the main title. Default is 16.")
parser$add_argument("--axis_title_size", type = "integer", default = 14,
                    help = "Font size for axis titles. Default is 14.")
parser$add_argument("--axis_text_size", type = "integer", default = 12,
                    help = "Font size for axis tick labels. Default is 12.")

parser$add_argument("--line_color", type = "character", nargs = "+",
                    default = c("blue", "red", "green"),
                    help = "Line colors. Default: blue, red, green.")
parser$add_argument("--line_type", type = "character", default = "solid",
                    help = "Line type. Default is solid.")
parser$add_argument("--line_opacity", type = "double", default = 1.0,
                    help = "Line opacity [0,1]. Default is 1.0.")
parser$add_argument("--line_thickness", type = "double", default = 1.0,
                    help = "Line thickness. Default is 1.0.")

parser$add_argument("--is_show_legend", type = "logical", default = TRUE,
                    help = "Show legend. Default is TRUE.")
parser$add_argument("--legend_title", type = "character", default = "Pathway",
                    help = "Legend title.")
parser$add_argument("--legend_title_size", type = "integer", default = 7,
                    help = "Legend title size. Default is 7.")
parser$add_argument("--legend_text_size", type = "integer", default = 10,
                    help = "Legend text size. Default is 10.")
parser$add_argument("--legend_position", type = "character", default = "right",
                    help = "Legend position. Default is right.")

parser$add_argument("--width", type = "double", default = 800,
                    help = "Plot width in px. Default is 800.")
parser$add_argument("--height", type = "double", default = 600,
                    help = "Plot height in px. Default is 600.")

args <- parser$parse_args()

get_script_path <- function() {
  a <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  script_path <- sub(file_arg, "", a[grep(file_arg, a)])
  normalizePath(script_path)
}

script_dir <- dirname(get_script_path())
msig_path <- file.path(script_dir, "../../../db/rda/msig_kegg.rda")

# Ensure enough colors for top_n
if (length(args$line_color) < args$top_n) {
  args$line_color <- rep(args$line_color, length.out = args$top_n)
} else {
  args$line_color <- args$line_color[1:args$top_n]
}

# =========================================================
# 2) Load input objects
#    Required objects inside input_rda: exp (expression matrix) and deg (DE table)
# =========================================================
load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

# =========================================================
# 3) Auto-detect ID type from rownames(deg)
# =========================================================
detect_id_type <- function(ids) {
  ids <- as.character(ids)
  if (mean(grepl("^ENSG\\d{11}", ids)) > 0.8) {
    "ENSEMBL"
  } else if (mean(grepl("^ENSP\\d{11}", ids)) > 0.8) {
    "ENSEMBLPROT"
  } else if (mean(grepl("^[OPQ][0-9][A-Z0-9]{3}[0-9]$", ids)) > 0.5) {
    "UNIPROT"
  } else if (mean(grepl("^[0-9]+$", ids)) > 0.8) {
    "ENTREZID"
  } else {
    "SYMBOL"
  }
}

row_ids <- rownames(deg)
id_type <- detect_id_type(row_ids)
message(paste("Auto-detected ID type:", id_type))
deg[[id_type]] <- row_ids

# =========================================================
# 4) Standard GSEA geneList (RANK ALL GENES; no significance filtering)
#    - Prefer limma t/stat if available (classic GSEA ranking)
#    - Otherwise fall back to logFC
# =========================================================
rank_stat <- if ("t" %in% colnames(deg)) {
  "t"
} else if ("stat" %in% colnames(deg)) {
  "stat"
} else {
  "logFC"
}
message(paste("Ranking statistic for GSEA:", rank_stat))

deg2 <- deg %>%
  mutate(
    P.Value   = suppressWarnings(as.numeric(P.Value)),
    adj.P.Val = suppressWarnings(as.numeric(adj.P.Val))
  )

supported_keytypes <- AnnotationDbi::keytypes(org.Hs.eg.db)
fromType <- id_type
if (!(fromType %in% supported_keytypes)) {
  warning(paste0(
    "Detected ID type '", id_type, "' is not supported by org.Hs.eg.db. ",
    "Falling back to SYMBOL mapping; results may be empty if IDs are not gene symbols."
  ))
  fromType <- "SYMBOL"
  deg2[["SYMBOL"]] <- row_ids
  id_type <- "SYMBOL"
}

gene_df <- bitr(
  deg2[[id_type]],
  fromType = fromType,
  toType   = "ENTREZID",
  OrgDb    = org.Hs.eg.db,
  drop     = TRUE
)

deg2 <- left_join(deg2, gene_df, by = id_type) %>%
  filter(!is.na(ENTREZID)) %>%
  filter(!is.na(.data[[rank_stat]]))

# De-duplicate ENTREZID by keeping the entry with the largest |rank_stat|
deg2 <- deg2 %>%
  group_by(ENTREZID) %>%
  slice_max(order_by = abs(.data[[rank_stat]]), n = 1, with_ties = FALSE) %>%
  ungroup()

geneList <- deg2[[rank_stat]]
names(geneList) <- as.character(deg2$ENTREZID)
geneList <- sort(geneList, decreasing = TRUE)

message(paste("geneList size (mapped & unique ENTREZID):", length(geneList)))

# If geneList is too small, fail gracefully (avoid GSEA() crashing the web pipeline)
if (length(geneList) < 10) {
  msg <- paste0(
    "Error: geneList too small (", length(geneList),
    "). ID mapping likely failed. Please check rownames(deg) and mapping keytype."
  )
  warning(msg)

  error_plot <- ggplot() +
    annotate("text", x = 0.5, y = 0.5, label = msg, size = 5, color = "red") +
    theme_void()

  ggsave(
    filename = args$output_png,
    plot = error_plot,
    width = args$width,
    height = args$height,
    units = "px",
    device = "png",
    dpi = 300
  )

  write.csv(data.frame(), file = args$output_csv, row.names = FALSE, quote = TRUE)
  quit(save = "no", status = 0)
}

# =========================================================
# 5) GSEA (KEGG_LEGACY from MSigDB via msigdbr)
# =========================================================
if (file.exists(msig_path)) {
  load(msig_path)  # expects object: msig_kegg
} else {
  msig_kegg <- msigdbr(
    species = "Homo sapiens",
    collection = "C2",
    subcollection = "CP:KEGG_LEGACY"
  )
  save(msig_kegg, file = msig_path)
}

kegg_term2gene <- dplyr::select(msig_kegg, gs_name, ncbi_gene)
GSEA_result <- GSEA(geneList, TERM2GENE = kegg_term2gene)

# =========================================================
# 6) Multi-pathway overlay plot (ES curves + ticks + ranked metric)
# =========================================================
draw_gsea_multilayer_patchwork <- function(gsea_result, args) {

  valid_results_df <- gsea_result@result %>% filter(setSize > 0)

  if (nrow(valid_results_df) == 0) {
    error_message <- "Error: No valid pathways with core enrichment found to plot."
    error_plot <- ggplot() +
      annotate("text", x = 0.5, y = 0.5, label = error_message, size = 6, color = "red") +
      theme_void()

    ggsave(
      filename = args$output_png,
      plot = error_plot,
      width = args$width,
      height = args$height,
      units = "px",
      device = "png",
      dpi = 300
    )
    message(paste("No valid pathways found. An error image was generated at:", args$output_png))
    return(invisible(NULL))
  }

  top_ids <- head(valid_results_df$ID, args$top_n)
  gene_list <- sort(gsea_result@geneList, decreasing = TRUE)

  # 1) Enrichment score (runningScore) curves
  es_data <- purrr::map_dfr(
    top_ids,
    ~{
      gsdata <- enrichplot:::gsInfo(gsea_result, geneSetID = .x)
      gsdata$pathway <- .x
      gsdata
    }
  )

  es_plot <- ggplot(es_data, aes(x = x, y = runningScore, color = pathway)) +
    geom_line(
      size = args$line_thickness,
      alpha = args$line_opacity,
      linetype = args$line_type
    ) +
    scale_color_manual(
      values = setNames(args$line_color[seq_along(unique(es_data$pathway))], unique(es_data$pathway)),
      name = args$legend_title
    ) +
    labs(
      title = args$main_title,
      y = args$y_axis_title,
      x = NULL
    ) +
    theme_minimal(base_size = 12) +
    theme(
      plot.title   = element_text(size = args$main_title_size, face = "bold", hjust = 0.5),
      axis.title.y = element_text(size = args$axis_title_size, face = "bold"),
      axis.text.x  = element_blank(),
      axis.ticks.x = element_blank(),
      axis.text.y  = element_text(size = args$axis_text_size),
      legend.position = if (args$is_show_legend) args$legend_position else "none",
      legend.title = element_text(size = args$legend_title_size, face = "bold"),
      legend.text  = element_text(size = args$legend_text_size),
      panel.grid.minor = element_blank(),
      legend.spacing = unit(0.1, "cm")
    )

  # 2) Middle ticks layer
  tick_data <- es_data %>%
    filter(position == 1) %>%
    mutate(tick_y = as.numeric(as.factor(pathway)))

  tick_plot <- ggplot(tick_data, aes(x = x, y = tick_y, color = pathway)) +
    geom_linerange(aes(ymin = tick_y - 0.4, ymax = tick_y + 0.4), size = 0.8) +
    scale_color_manual(
      values = setNames(args$line_color[seq_along(unique(tick_data$pathway))], unique(tick_data$pathway)),
      guide = "none"
    ) +
    theme_void() +
    theme(
      legend.position = "none",
      axis.text.y = element_blank()
    )

  # 3) Bottom ranked metric
  rank_df <- data.frame(x = seq_along(gene_list), value = gene_list)
  rank_plot <- ggplot(rank_df, aes(x = x, y = value)) +
    geom_col(fill = "grey70", width = 1.0) +
    labs(x = args$x_axis_title, y = "Ranked Metric") +
    theme_minimal(base_size = 12) +
    theme(
      axis.title = element_text(size = args$axis_title_size, face = "bold"),
      axis.text  = element_text(size = args$axis_text_size),
      panel.grid.minor = element_blank()
    )

  final_plot <- es_plot / tick_plot / rank_plot +
    plot_layout(heights = c(3.2, 0.5, 1.5))

  ggsave(
    filename = args$output_png,
    plot = final_plot,
    width = args$width,
    height = args$height,
    units = "px",
    device = "png",
    dpi = 300
  )

  # Optional PDF
  if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
    ggsave(
      filename = args$output_pdf,
      plot = final_plot,
      width = args$width / 300,
      height = args$height / 300,
      units = "in",
      device = cairo_pdf
    )
  }

  invisible(final_plot)
}

draw_gsea_multilayer_patchwork(
  gsea_result = GSEA_result,
  args = args
)

write.csv(GSEA_result@result, file = args$output_csv, row.names = FALSE, quote = TRUE)
