#!/usr/bin/env Rscript

library(tidyverse)
library(org.Hs.eg.db)
library(clusterProfiler)
library(multiMiR)
library(enrichplot)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Perform DESeq2 differential expression analysis.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_rda", type="character", required=TRUE, help="Path to save the DESeq results object (e.g., DEG.rda).")
parser$add_argument("--is_mrna", type="logical", default=TRUE, help="Whether the input data is mRNA (default: TRUE). If FALSE, it is assumed to be miRNA.")
args <- parser$parse_args()

get_script_path <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  script_path <- sub(file_arg, "", args[grep(file_arg, args)])
  return(normalizePath(script_path))
}

script_dir <- dirname(get_script_path())
mapping_path <- file.path(script_dir, "../../../db/rda/mapping.txt")

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

convert <- function(miRNA_expr_df) {
  if (!file.exists(mapping_path)) {
    stop(paste("Mapping file not found at:", mapping_path))
  }
  mapping_df <- read.delim(mapping_path, stringsAsFactors = FALSE, sep = "\t", check.names = FALSE)
  
  common_mirnas <- intersect(mapping_df$miRNA, miRNA_expr_df$miRNA)
  mapping_df <- mapping_df[mapping_df$miRNA %in% common_mirnas, ]

  return(mapping_df)
}

if (args$is_mrna) {
  row_ids <- rownames(deg)
  ensembl_ratio <- mean(grepl("^ENSG\\d{11}", row_ids))
  id_type <- if (ensembl_ratio > 0.8) "ENSEMBL" else "SYMBOL"
  message(paste("Auto-detected ID type:", id_type))
  deg[[id_type]] <- row_ids

  entrez_df <- bitr(
    deg[[id_type]],
    fromType = id_type,
    toType   = "ENTREZID",
    OrgDb    = org.Hs.eg.db
  )
} else {
  deg <- deg %>% rownames_to_column("raw_name") %>% mutate(miRNA = sub("/.*", "", raw_name))
  mir_targets_df <- convert(deg)
  deg <- left_join(deg, mir_targets_df, by = c("miRNA" = "miRNA"))
  colnames(deg)[colnames(deg) == "Gene Symbol"] <- "target_symbol"

  # Map SYMBOL to ENTREZID
  entrez_df <- bitr(
    deg$target_symbol,
    fromType = "SYMBOL",
    toType   = "ENTREZID",
    OrgDb    = org.Hs.eg.db
  )
  id_type <- "SYMBOL"
  colnames(deg)[colnames(deg) == "target_symbol"] <- id_type
}

deg <- left_join(deg, entrez_df, by = id_type)
save(deg, file = args$output_rda)
