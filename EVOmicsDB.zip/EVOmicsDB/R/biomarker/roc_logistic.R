#!/usr/bin/env Rscript

library(pROC)
library(ggplot2)
library(dplyr)
library(argparse)

parser <- ArgumentParser(description="Perform differential expression analysis and logistic regression modeling.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to the output PNG file.")
parser$add_argument("--output_csv", type="character", required=TRUE, help="Path to the output CSV file for ROC curve data.")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--custom_gene", type="character", nargs = "+", default=c("GENE1", "GENE2", "GENE3"), help="")
parser$add_argument("--line_color", type="character", default="grey50", help="")
parser$add_argument("--line_type", type="character", default="solid", help="Line type for ROC lines (e.g.,'solid', 'dashed', 'dotted'). Default is solid.")
parser$add_argument("--line_opacity", type="double", default=1.0, help="Opacity for ROC lines (value between 0 and 1). Default is 1.0.")
parser$add_argument("--line_thickness", type="double", default=1.5, help="Line thickness for ROC lines. Default is 1.5.")
parser$add_argument("--main_title", type="character", default="ROC Curve", help="Main title of the plot. Default is 'ROC Curve'.")
parser$add_argument("--x_axis_title", type="character", default="1 - Specificity (False Positive Rate)", help="X-axis title. Default is '1 - Specificity (False Positive Rate)'.")
parser$add_argument("--y_axis_title", type="character", default="Sensitivity (True Positive Rate)", help="Y-axis title. Default is 'Sensitivity (True Positive Rate)'.")
parser$add_argument("--main_title_size", type="double", default=16, help="Font size for the main title. Default is 16.")
parser$add_argument("--axis_title_size", type="double", default=14, help="Font size for X and Y axis titles. Default is 14.")
parser$add_argument("--axis_text_size", type="double", default=12, help="Font size for X and Y axis tick labels. Default is 12.")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Show the legend (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--legend_text_size", type="double", default=10, help="Font size for legend text. Default is 10.")
parser$add_argument("--legend_position", type="character", default="bottomright", help="Position of the legend (e.g., 'bottomright', 'topleft', 'inside'). Default is 'bottomright'.")
parser$add_argument("--is_show_diag_line", type="logical", default=TRUE, help="Show the diagonal reference line (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--diag_line_color", type="character", default="grey50", help="Color for the diagonal line. Default is 'grey50'.")
parser$add_argument("--diag_line_type", type="character", default="dashed", help="Line type for the diagonal line (e.g., 'dashed', 'dotted'). Default is 'dashed'.")
parser$add_argument("--diag_line_thickness", type="double", default=1.0, help="Line thickness for the diagonal line. Default is 1.0.")
parser$add_argument("--is_show_auc", type="logical", default=TRUE, help="Show AUC value on the plot (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--auc_text_opacity", type="double", default=0.1, help="Opacity for the ROC curve shaded area (value between 0 and 1). Default is 0.1. Controls the transparency of the area under the curve.")
parser$add_argument("--is_show_cutoff", type="logical", default=TRUE, help="Show cutoff point and/or text on the plot (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--cutoff_text_size", type="double", default=10, help="Font size for cutoff value text. Default is 10.")
parser$add_argument("--cutoff_point_size", type="double", default=3.0, help="Size of the point marker for the cutoff value. Default is 3.0.")
parser$add_argument("--width", type="double", default=800, help="Width of the output plot. unit px. Default is 800.")
parser$add_argument("--height", type="double", default=600, help="Height of the output plot. unit px. Default is 600.")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

sample_names <- colnames(exp)
group <- factor(ifelse(substr(sample_names, 1, 1) == "N", "Control", "Tumor"), levels = c("Control", "Tumor"))

###### 5. Logistic model fitting module ######
fit_logistic_model <- function(exp, group, custom_genes = NULL) {
  genes_use <- custom_genes
  
  model_data <- data.frame(t(exp[genes_use, ]), Group = group)
  model_data$Group <- ifelse(model_data$Group == "Tumor", 1, 0)

  logi_model <- glm(Group ~ ., data = model_data, family = binomial)
  prob_pred <- predict(logi_model, type = "response")
  
  return(list(
    model = logi_model,
    prob = prob_pred,
    genes_used = genes_use,
    response = model_data$Group
  ))
}

logi_result <- fit_logistic_model(
  exp, 
  group,
  custom_genes = args$custom_gene
)

logi_result$label<-"Logistic Regression"
model_list <- list(logi_result)

# Ensure the number of colors and line types matches top_n
colors <- c(args$line_color)
  
roc_df_list <- list()
cutpoints <- c()
aucs <- c()
  
for (i in seq_along(model_list)) {
  prob_pred <- model_list[[i]]$prob
  true_labels <- model_list[[i]]$response
  label <- model_list[[i]]$label
    
  roc_obj <- roc(response = true_labels, predictor = prob_pred, levels = c(0,1), direction = "<")
    
  # Show AUC in the legend depending on the is_show_auc flag
  if (args$is_show_auc) {
    model_label <- paste0(label, " (AUC=", round(auc(roc_obj), 3), ")")
  } else {
    model_label <- label
  }
  
  df <- data.frame(
    FPR = 1 - roc_obj$specificities,
    TPR = roc_obj$sensitivities,
    model = model_label
  )
  
  df <- df[order(df$FPR, df$TPR), ]
  roc_df_list[[i]] <- df
  aucs[i] <- auc(roc_obj)
    
  # Best cutoff (Youden index)
  youden <- which.max(roc_obj$sensitivities + roc_obj$specificities - 1)
  cutpoints[i] <- roc_obj$thresholds[youden]
    
  model_list[[i]]$roc_obj <- roc_obj  # Stored for downstream use
  model_list[[i]]$youden <- youden
}
  
# Combine all data
roc_df <- do.call(rbind, roc_df_list)
roc_df$model <- factor(roc_df$model, levels = unique(roc_df$model))
  
# Start plotting
gg <- ggplot(roc_df, aes(x = FPR, y = TPR, color = model)) +
  geom_step(
    linewidth = args$line_thickness, 
    linetype = args$line_type, 
    alpha = args$line_opacity, 
    direction = "hv"
  ) +
  scale_color_manual(values = colors) +
  scale_x_continuous(expand = c(0, 0), limits = c(0, 1)) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 1)) +
  coord_equal(xlim = c(0, 1), ylim = c(0, 1)) +
  theme_minimal(base_size = 13) +
  labs(x=args$x_axis_title, y=args$y_axis_title, title=args$main_title) +
  theme(
    plot.title = element_text(size = args$main_title_size, face = "bold", hjust = 0.5),
    axis.title = element_text(size = args$axis_title_size, face = "bold"),
    axis.text = element_text(size = args$axis_text_size),
    legend.text = element_text(size = args$legend_text_size),
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
    legend.position = if(args$is_show_legend) args$legend_position else "none",
    legend.background = element_rect(fill = NA, color = NA), 
    legend.box.background = element_rect(fill = NA, color = NA)
  )

# Add shaded area depending on the is_show_auc flag
if(args$is_show_auc) {
  gg <- gg + 
    geom_area(aes(fill = model), position = "identity", alpha = args$auc_text_opacity, color = NA) +
    scale_fill_manual(values = colors)
}

# Set legend.justification only when legend is shown and positioned inside
if(args$is_show_legend && tolower(args$legend_position) == "inside") {
  gg <- gg + theme(legend.justification = c("right", "bottom"))
}

if(args$is_show_diag_line){
  gg <- gg + geom_abline(
    slope=1, intercept=0, 
    linetype=args$diag_line_type, 
    color=args$diag_line_color, 
    linewidth=args$diag_line_thickness
  )
}

# Add the best cutoff point
if(args$is_show_cutoff) {
  for (i in seq_along(model_list)) {
    roc_obj <- model_list[[i]]$roc_obj
    youden <- model_list[[i]]$youden
    
    FPR_best <- 1 - roc_obj$specificities[youden]
    TPR_best <- roc_obj$sensitivities[youden]
    threshold_best <- roc_obj$thresholds[youden]
    
    gg <- gg +
      annotate(
        "point", 
        x = FPR_best, 
        y = TPR_best, 
        color = colors[i], 
        size = args$cutoff_point_size
      ) +
      annotate(
        "text", 
        x = FPR_best, 
        y = TPR_best + 0.05,
        label = round(threshold_best, 4), 
        color = colors[i], 
        size = args$cutoff_text_size,
        alpha = 1.0,
        hjust = 0
      )
  }
}

# Save to PNG
ggsave(
  filename = args$output_png,
  plot = gg,
  width = args$width,
  height = args$height,
  units = "px",
  device = "png",
  dpi = 300
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = gg,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

# Save ROC curve data to CSV
write.csv(roc_df, file = args$output_csv, row.names = FALSE)
