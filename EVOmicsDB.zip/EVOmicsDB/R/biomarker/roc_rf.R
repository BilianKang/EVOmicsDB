#!/usr/bin/env Rscript

library(limma)
library(randomForest)
library(e1071)
library(pROC)
library(caret)
library(dplyr)
library(edgeR)
library(argparse)

parser <- ArgumentParser(description="Perform differential expression analysis and feature selection using SVM.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_csv", type="character", required=FALSE, help="Path to save the filtered differentially expressed genes as a CSV file (e.g., filtered_DEG.csv).")
parser$add_argument("--is_use_padj", type="logical", required=FALSE, default=TRUE, help="Whether to use padj for filtering.")
parser$add_argument("--log2fc_threshold", type="numeric", default=1, help="Log2 fold change threshold for significance (default: 1).")
parser$add_argument("--pvalue_threshold", type="numeric", default=0.05, help="P-value threshold for significance (default: 0.05).")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

sample_names <- colnames(exp)
group <- factor(ifelse(substr(sample_names, 1, 1) == "N", "Control", "Tumor"), levels = c("Control", "Tumor"))

# 2. Differential expression module
do_diff_expr <- function(deg, p_cut = 0.05, logfc_cut = 1, is_use_padj = TRUE) {
  if (is_use_padj) {
    deg_filtered <- deg %>% filter(adj.P.Val < p_cut & abs(logFC) > logfc_cut)
  } else {
    deg_filtered <- deg %>% filter(P.Value < p_cut & abs(logFC) > logfc_cut)
  }
  return(list(
    deg_all = deg,
    deg_filtered = deg_filtered,
    gene_list = rownames(deg_filtered)
  ))
}

# Ensure the DE filtering returns more than 5 genes by iteratively relaxing thresholds
logfc_cut <- args$log2fc_threshold
p_cut <- args$pvalue_threshold
# Minimum number of DE genes required
min_gene_num <- 5
# Iterative filtering loop
repeat {
  data1 <- do_diff_expr(deg, p_cut = p_cut, logfc_cut = logfc_cut, is_use_padj = args$is_use_padj)
  if (length(data1$gene_list) > min_gene_num) {
    message("Filtering successful: number of differentially expressed genes = ", length(data1$gene_list))
    break
  }
  # Dynamically relax thresholds
  logfc_cut <- logfc_cut - 0.05
  p_cut <- p_cut + 0.01

  # Stop if thresholds are relaxed too far to avoid an infinite loop
  if (logfc_cut <= 0.1 || p_cut >= 0.5) {
    warning("Maximum relaxation range reached, still not enough differentially expressed genes found.")
    break
  }
}

###### 4. Feature selection module ######
gene_selector <- function(exp, group, genes) {
  sub_exp <- exp[genes, ]
  
  # 2. Build training data: samples as rows, genes as columns + group labels
  x <- t(sub_exp)                   # Feature matrix: samples × genes
  y <- group                        # Group labels (factor)
  
  set.seed(123)
  rf_model <- randomForest(x = x, y = y, importance = TRUE, ntree = 500)
  
  # 3. Extract feature importance
  scores <- importance(rf_model)[, "MeanDecreaseGini"]
  score_df <- data.frame(Gene = names(scores), Importance = scores) %>% arrange(desc(Importance))
  return(score_df)
}

importance_table <- gene_selector(exp, group, data1$gene_list)
write.csv(importance_table, file = args$output_csv, row.names = T, quote = TRUE)
