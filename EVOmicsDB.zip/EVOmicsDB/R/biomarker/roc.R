#!/usr/bin/env Rscript

library(pROC)
library(ggplot2)
library(dplyr)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Generate a plot for roc.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to the output PNG file.")
parser$add_argument("--output_csv", type="character", required=TRUE, help="Path to the output CSV file for ROC curve data.")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--top_n", type="integer", default=10, help="Number of top pathways or terms to display. Default is 10.")
parser$add_argument("--custom_gene", type="character", nargs = "*", default=NULL, help="Custom gene(s) to plot ROC for. Overrides top_n when provided.")
parser$add_argument("--line_color", type="character", nargs = "+", default=c("blue", "red", "green"), help="Color of lines (e.g., 'blue', 'red', 'green'). Default is blue, red, green.")
parser$add_argument("--line_type", type="character", default="solid", help="Line type for ROC lines (e.g.,'solid', 'dashed', 'dotted'). Default is solid.")
parser$add_argument("--line_opacity", type="double", default=1.0, help="Opacity for ROC lines (value between 0 and 1). Default is 1.0.")
parser$add_argument("--line_thickness", type="double", default=1.5, help="Line thickness for ROC lines. Default is 1.5.")
parser$add_argument("--main_title", type="character", default="ROC Curve", help="Main title of the plot. Default is 'ROC Curve'.")
parser$add_argument("--x_axis_title", type="character", default="1 - Specificity (False Positive Rate)", help="X-axis title. Default is '1 - Specificity (False Positive Rate)'.")
parser$add_argument("--y_axis_title", type="character", default="Sensitivity (True Positive Rate)", help="Y-axis title. Default is 'Sensitivity (True Positive Rate)'.")
parser$add_argument("--main_title_size", type="double", default=16, help="Font size for the main title. Default is 16.")
parser$add_argument("--axis_title_size", type="double", default=14, help="Font size for X and Y axis titles. Default is 14.")
parser$add_argument("--axis_text_size", type="double", default=12, help="Font size for X and Y axis tick labels. Default is 12.")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Show the legend (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--legend_text_size", type="double", default=10, help="Font size for legend text. Default is 10.")
parser$add_argument("--legend_position", type="character", default="bottomright", help="Position of the legend (e.g., 'bottomright', 'topleft', 'inside'). Default is 'bottomright'.")
parser$add_argument("--is_show_diag_line", type="logical", default=TRUE, help="Show the diagonal reference line (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--diag_line_color", type="character", default="grey50", help="Color for the diagonal line. Default is 'grey50'.")
parser$add_argument("--diag_line_type", type="character", default="dashed", help="Line type for the diagonal line (e.g., 'dashed', 'dotted'). Default is 'dashed'.")
parser$add_argument("--diag_line_thickness", type="double", default=1.0, help="Line thickness for the diagonal line. Default is 1.0.")
parser$add_argument("--is_show_auc", type="logical", default=TRUE, help="Show AUC value on the plot (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--auc_text_opacity", type="double", default=0.1, help="Opacity for the ROC curve shaded area (value between 0 and 1). Default is 0.1. Controls the transparency of the area under the curve.")
parser$add_argument("--is_show_cutoff", type="logical", default=TRUE, help="Show cutoff point and/or text on the plot (TRUE/FALSE). Default is TRUE.")
parser$add_argument("--cutoff_text_size", type="double", default=10, help="Font size for cutoff value text. Default is 10.")
parser$add_argument("--cutoff_point_size", type="double", default=3.0, help="Size of the point marker for the cutoff value. Default is 3.0.")
parser$add_argument("--width", type="double", default=800, help="Width of the output plot. unit px. Default is 800.")
parser$add_argument("--height", type="double", default=600, help="Height of the output plot. unit px. Default is 600.")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

sample_names <- colnames(exp)
group <- factor(ifelse(substr(sample_names, 1, 1) == "N", "Control", "Tumor"), levels = c("Control", "Tumor"))

if (!is.null(args$custom_gene) && length(args$custom_gene) > 0) {
  genes_to_plot <- intersect(args$custom_gene, rownames(exp))
  if (length(genes_to_plot) == 0) {
    stop("None of the provided custom_gene exist in the expression matrix.")
  }
  # Adjust color vector length to match custom genes count
  if (length(args$line_color) < length(genes_to_plot)) {
    args$line_color <- rep(args$line_color, length.out = length(genes_to_plot))
  } else {
    args$line_color <- args$line_color[1:length(genes_to_plot)]
  }
} else {
  # Compute AUC for every gene and take top_n
  auc_list <- sapply(rownames(exp), function(gene){
    expr <- as.numeric(exp[gene, ])
    roc_res <- try(roc(response=group, predictor=expr, levels=c("Control","Tumor"), direction="<"), silent=TRUE)
    if(inherits(roc_res, "try-error")) return(NA)
    auc(roc_res)
  })
  auc_sorted <- sort(auc_list, decreasing = TRUE)
  genes_to_plot <- names(auc_sorted)[1:args$top_n]

  # Adjust color vector length to match top_n
  if (length(args$line_color) < args$top_n) {
    args$line_color <- rep(args$line_color, length.out = args$top_n)
  } else {
    args$line_color <- args$line_color[1:args$top_n]
  }
}

# Final colors vector
colors <- args$line_color

roc_df_list <- list()
for(i in seq_along(genes_to_plot)){
  gene <- genes_to_plot[i]
  expr <- as.numeric(exp[gene, ])
  roc_obj <- roc(group, expr, levels=c("Control", "Tumor"), direction="<")
  
  gene_display_name <- gene
  if(args$is_show_auc) {
    gene_display_name <- paste0(gene, " (AUC=", round(auc(roc_obj),3), ")")
  }
  
  df <- data.frame(
    FPR = 1 - roc_obj$specificities,
    TPR = roc_obj$sensitivities,
    gene = gene_display_name,
    original_gene = gene
  )
  df <- df[order(df$FPR, df$TPR), ]
  roc_df_list[[i]] <- df
}

roc_df <- do.call(rbind, roc_df_list)
roc_df$gene <- factor(roc_df$gene, levels=sapply(genes_to_plot, function(g){
    roc_obj_temp <- roc(group, as.numeric(exp[g,]), levels=c("Control", "Tumor"), direction="<", quiet=TRUE)
    if(args$is_show_auc) paste0(g, " (AUC=", round(auc(roc_obj_temp),3), ")") else g
}))

# Plot
gg <- ggplot(roc_df, aes(x=FPR, y=TPR, color=gene, group=gene)) +
  geom_step(
    linewidth = args$line_thickness, 
    linetype = args$line_type, 
    alpha = args$line_opacity, 
    direction = "hv"
  ) +
  scale_color_manual(values=colors, name=NULL) +
  scale_x_continuous(expand = c(0, 0), limits = c(0, 1)) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 1)) +
  coord_equal(xlim=c(0,1), ylim=c(0,1)) +
  theme_minimal(base_size=13) +
  labs(x=args$x_axis_title, y=args$y_axis_title, title=args$main_title) +
  theme(
    plot.title = element_text(size = args$main_title_size, face = "bold", hjust = 0.5),
    axis.title = element_text(size = args$axis_title_size, face = "bold"),
    axis.text  = element_text(size = args$axis_text_size),
    legend.text  = element_text(size = args$legend_text_size),
    panel.border = element_rect(colour = "black", fill = NA, linewidth = 0.5),
    legend.position = if(args$is_show_legend) args$legend_position else "none",
    legend.background = element_rect(fill = NA, color = NA), 
    legend.box.background = element_rect(fill = NA, color = NA)
  )

# Add shaded area depending on is_show_auc
if(args$is_show_auc) {
  gg <- gg + 
    geom_area(aes(fill=gene), position='identity', alpha=args$auc_text_opacity, color=NA) +
    scale_fill_manual(values=colors, name=NULL)
}

# Only set legend.justification when legend is shown and position is inside
if(args$is_show_legend && tolower(args$legend_position) == "inside") {
  gg <- gg + theme(legend.justification = c("right", "bottom"))
}

if(args$is_show_diag_line){
  gg <- gg + geom_abline(
    slope=1, intercept=0, 
    linetype=args$diag_line_type, 
    color=args$diag_line_color, 
    linewidth=args$diag_line_thickness
  )
}

if(args$is_show_cutoff) {
  for(i in seq_along(genes_to_plot)){
    gene <- genes_to_plot[i]
    expr <- as.numeric(exp[gene, ])
    roc_obj <- roc(group, expr, levels=c("Control", "Tumor"), direction="<", quiet=TRUE)
    
    # Find the point with the maximum Youden index
    coords_obj <- coords(roc_obj, "best", ret="all", best.method="youden")
    
    # Use annotate to add the point and label, and apply the new parameters
    gg <- gg +
      annotate(
        "point", 
        x = 1 - coords_obj$specificity, 
        y = coords_obj$sensitivity, 
        color = colors[i], 
        size = args$cutoff_point_size
      ) +
      annotate(
        "text",  
        x = 1 - coords_obj$specificity + 0.02, 
        y = coords_obj$sensitivity - 0.02, # Adjust position to avoid overlap
        label = round(coords_obj$threshold, 2), 
        color = colors[i], 
        size = args$cutoff_text_size,
        alpha = 1.0,
        hjust = 0
      ) 
  }
}

# Save as PNG file
ggsave(
  filename = args$output_png,
  plot = gg,
  width = args$width,
  height = args$height,
  units = "px",
  device = "png",
  dpi = 300
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = gg,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

# Save ROC curve data to CSV file
write.csv(roc_df, file = args$output_csv, row.names = FALSE)