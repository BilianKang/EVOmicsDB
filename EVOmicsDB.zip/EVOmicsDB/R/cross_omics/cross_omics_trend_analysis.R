#!/usr/bin/env Rscript

library(tidyverse)
library(ggplot2)
library(ggpubr)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Generate expression trend scatter plot with correlation analysis for two omics datasets.")

# Input files
parser$add_argument("--input_file1", type="character", required=TRUE, help="Path to the first omics differential analysis result file (e.g., DA_result_RNA.txt).")
parser$add_argument("--input_file2", type="character", required=TRUE, help="Path to the second omics differential analysis result file (e.g., DA_result_miRNA.txt).")
parser$add_argument("--omics1_name", type="character", required=TRUE, help="Display name for the first omics dataset (e.g., 'mRNA_GSE255775').")
parser$add_argument("--omics2_name", type="character", required=TRUE, help="Display name for the second omics dataset (e.g., 'miRNA_GSE39833').")

# Output files
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to save the scatter plot (e.g., correlation_scatter.png).")
parser$add_argument("--output_csv", type="character", default=NULL, help="Path to save the correlation result as CSV (optional).")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")

# Titles
parser$add_argument("--main_title", type="character", default="", help="Main title of the plot. If empty, auto-generated based on omics names.")
parser$add_argument("--x_axis_title", type="character", default="log2FC", help="X-axis title (default: log2FC).")
parser$add_argument("--y_axis_title", type="character", default="Random Index (scatter)", help="Y-axis title (default: Random Index (scatter)).")
parser$add_argument("--main_title_size", type="numeric", default=14, help="Font size of main title (default: 14).")
parser$add_argument("--axis_title_font_size", type="numeric", default=12, help="Font size of axis titles (default: 12).")
parser$add_argument("--axis_text_font_size", type="numeric", default=10, help="Font size of axis text labels (default: 10).")

# Dot (scatter point) settings
parser$add_argument("--dot_size", type="numeric", default=2, help="Size of scatter points (default: 2).")
parser$add_argument("--dot_alpha", type="numeric", default=0.7, help="Transparency of scatter points (default: 0.7).")
parser$add_argument("--fill_colors", type="character", default="#1f78b4,#33a02c,#e31a1c,#ff7f00", help="Comma-separated colors for Omics1.Up, Omics1.Down, Omics2.Up, Omics2.Down (default: #1f78b4,#33a02c,#e31a1c,#ff7f00).")
parser$add_argument("--border_color", type="character", default="black", help="Border color for scatter points (default: black).")
parser$add_argument("--border_size", type="numeric", default=0.5, help="Border size for scatter points (default: 0.5).")
parser$add_argument("--is_show_border", type="logical", default=TRUE, help="Whether to show border for scatter points (default: TRUE).")

# Density curve settings
parser$add_argument("--density_line_size", type="numeric", default=1, help="Line width of density curves (default: 1).")
parser$add_argument("--density_color1", type="character", default="#1f78b4", help="Color of density curve for first omics (default: #1f78b4).")
parser$add_argument("--density_color2", type="character", default="#e31a1c", help="Color of density curve for second omics (default: #e31a1c).")
parser$add_argument("--is_show_density", type="logical", default=TRUE, help="Whether to show density curves (default: TRUE).")

# Legend settings
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Whether to show the legend (default: TRUE).")
parser$add_argument("--legend_title", type="character", default="Omics & Direction", help="Legend title (default: Omics & Direction).")
parser$add_argument("--legend_title_size", type="numeric", default=10, help="Font size of legend title (default: 10).")
parser$add_argument("--legend_text_size", type="numeric", default=9, help="Font size of legend text (default: 9).")
parser$add_argument("--legend_position", type="character", default="right", help="Legend position: 'right', 'left', 'top', 'bottom', or 'none' (default: right).")

# Export settings
parser$add_argument("--width", type="numeric", default=8.5, help="Width of the output image (default: 8.5, unit: inches).")
parser$add_argument("--height", type="numeric", default=5, help="Height of the output image (default: 5, unit: inches).")

args <- parser$parse_args()

# --- 2. Helper: read inputs ---
read_omics_rda <- function(rda_file) {
  # Load the 'deg' object from an RDA file
  env <- new.env()
  load(rda_file, envir = env)
  if (!exists("deg", envir = env)) {
    stop(paste("deg object not found in", rda_file))
  }
  df <- env$deg
  # Convert rownames to an ID column
  df$ID <- rownames(df)
  df %>% filter(!is.na(logFC))
}

# --- 3. Read inputs ---
omics1_diff <- read_omics_rda(args$input_file1)
omics2_diff <- read_omics_rda(args$input_file2)

# Add omics source and direction
omics1_sig <- omics1_diff %>% mutate(Omics = args$omics1_name, Direction = ifelse(logFC > 0, "Up", "Down"))
omics2_sig <- omics2_diff %>% mutate(Omics = args$omics2_name, Direction = ifelse(logFC > 0, "Up", "Down"))

# Merge
df_plot <- bind_rows(omics1_sig, omics2_sig)

# Add a random index to reduce y-axis overlap
set.seed(123)
df_plot <- df_plot %>% mutate(Index = sample(1:nrow(df_plot)))

# Create the Group column and set factor order
df_plot <- df_plot %>%
  mutate(Group = interaction(Omics, Direction)) %>%
  mutate(Group = factor(Group,
                        levels = c(
                          paste0(args$omics1_name, ".Up"),
                          paste0(args$omics1_name, ".Down"),
                          paste0(args$omics2_name, ".Up"),
                          paste0(args$omics2_name, ".Down")
                        )))

# --- 4. Compute concordance (correlation) ---
n <- min(nrow(omics1_sig), nrow(omics2_sig))
cor_res <- cor.test(omics1_sig$logFC[1:n], omics2_sig$logFC[1:n], method = "pearson")
R2 <- cor_res$estimate^2
pval <- cor_res$p.value
cor_coef <- cor_res$estimate

# --- 5. Parse color arguments ---
fill_color_list <- strsplit(args$fill_colors, ",")[[1]]
fill_color_list <- trimws(fill_color_list)
if (length(fill_color_list) != 4) {
  stop("fill_colors must contain exactly 4 colors separated by commas (Omics1.Up, Omics1.Down, Omics2.Up, Omics2.Down).")
}

colors <- setNames(
  fill_color_list,
  c(
    paste0(args$omics1_name, ".Up"),
    paste0(args$omics1_name, ".Down"),
    paste0(args$omics2_name, ".Up"),
    paste0(args$omics2_name, ".Down")
  )
)

# --- 6. Determine y-axis range for the density layer ---
max_idx <- max(df_plot$Index)

# Append counts to group labels
group_counts <- df_plot %>% 
  group_by(Group) %>% 
  summarise(n = n())

legend_labels <- paste0(group_counts$Group, " (n=", group_counts$n, ")")
names(legend_labels) <- group_counts$Group

# --- 7. Build the main title ---
if (args$main_title == "") {
  main_title <- paste0("Expression Trend Scatter with Density: ", args$omics1_name, " vs ", args$omics2_name)
} else {
  main_title <- args$main_title
}

# --- 8. Define plot theme ---
legend_pos <- if (tolower(args$legend_position) == "none" || !args$is_show_legend) "none" else args$legend_position

# --- 9. Build plot ---
# Configure point borders based on is_show_border
if (args$is_show_border) {
  p <- ggplot(df_plot, aes(x = logFC, y = Index, fill = Group)) +
    geom_point(shape = 21, size = args$dot_size, alpha = args$dot_alpha,
               color = args$border_color, stroke = args$border_size)
} else {
  p <- ggplot(df_plot, aes(x = logFC, y = Index, fill = Group)) +
    geom_point(shape = 21, size = args$dot_size, alpha = args$dot_alpha,
               color = NA, stroke = 0)
}

# Add density layer (if enabled)
if (args$is_show_density) {
  p <- p +
    geom_density(data = df_plot %>% filter(Omics == args$omics1_name),
                 aes(x = logFC, y = after_stat(scaled) * max_idx),
                 color = args$density_color1, size = args$density_line_size, fill = NA) +
    geom_density(data = df_plot %>% filter(Omics == args$omics2_name),
                 aes(x = logFC, y = after_stat(scaled) * max_idx),
                 color = args$density_color2, size = args$density_line_size, fill = NA)
}

p <- p +
  geom_vline(xintercept = 0, linetype = "dashed") +
  scale_y_continuous(
    name = args$y_axis_title,
    sec.axis = sec_axis(~ . / max_idx, name = "Probability Density")
  ) +
  scale_fill_manual(values = colors, labels = legend_labels)

# Add correlation annotation (shown by default; size = 4)
p <- p +
  annotate("text",
           x = min(df_plot$logFC, na.rm = TRUE),
           y = max_idx,
           label = paste0("R² = ", signif(R2, 2), "\n", "p = ", signif(pval, 3)),
           hjust = 0, vjust = 1,
           size = 4)

p <- p +
  theme_classic() +
  theme(
    plot.title = element_text(size = args$main_title_size, hjust = 0.5),
    axis.title = element_text(size = args$axis_title_font_size),
    axis.text = element_text(size = args$axis_text_font_size),
    legend.title = element_text(size = args$legend_title_size),
    legend.text = element_text(size = args$legend_text_size),
    legend.position = legend_pos
  ) +
  labs(
    x = args$x_axis_title,
    fill = args$legend_title,
    title = main_title,
    caption = "Density curves scaled; right y-axis shows probability"
  )

# --- 10. Save plot ---
ggsave(args$output_png, plot = p, width = args$width, height = args$height)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = p,
    width = args$width,
    height = args$height,
    units = "in",
    device = cairo_pdf
  )
}

# --- 11. Save correlation summary to CSV (if output_csv is provided) ---
if (!is.null(args$output_csv) && nzchar(args$output_csv)) {
  cor_result <- data.frame(
    omics1 = args$omics1_name,
    omics2 = args$omics2_name,
    method = "pearson",
    correlation = cor_coef,
    R_squared = R2,
    p_value = pval,
    n_samples = n,
    omics1_n = nrow(omics1_sig),
    omics2_n = nrow(omics2_sig)
  )
  write.csv(cor_result, file = args$output_csv, row.names = FALSE, quote = FALSE)
}
