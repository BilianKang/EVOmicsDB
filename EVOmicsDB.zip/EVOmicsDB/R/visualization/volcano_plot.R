#!/usr/bin/env Rscript

library(ggplot2)
library(dplyr)
library(argparse)

parser <- ArgumentParser(description="Generate a volcano plot from DESeq2 results.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to save the volcano plot (e.g., volcano_plot.png).")
parser$add_argument("--output_csv", type="character", default=NULL, help="Optional path to save the plot data as a CSV file (e.g., plot_data.csv).")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., volcano_plot.pdf).")
parser$add_argument("--is_use_padj", type="logical", default=TRUE, help="Whether to use adjusted p-values (default: TRUE).")
parser$add_argument("--log2fc_threshold", type="numeric", default=1, help="Log2 fold change threshold for significance (default: 1).")
parser$add_argument("--pvalue_threshold", type="numeric", default=0.05, help="P-value threshold for significance (default: 0.05).")
parser$add_argument("--is_x_axis_auto", type="logical", default=TRUE, help="Whether to set x-axis limits automatically.")
parser$add_argument("--x_axis_low", type="numeric", default=-1, help="Lower limit for the x-axis.")
parser$add_argument("--x_axis_high", type="numeric", default=1, help="Upper limit for the x-axis.")
parser$add_argument("--is_y_axis_auto", type="logical", default=TRUE, help="Whether to set y-axis limits automatically.")
parser$add_argument("--y_axis_low", type="numeric", default=0, help="Lower limit for the y-axis.")
parser$add_argument("--y_axis_high", type="numeric", default=10, help="Upper limit for the y-axis.")
parser$add_argument("--main_title", type="character", default="Volcano Plot", help="Title for the plot.")
parser$add_argument("--x_axis_title", type="character", default="Log2 Fold Change", help="Title for the x-axis.")
parser$add_argument("--y_axis_title", type="character", default="-Log10(p-value)", help="Title for the y-axis.")
parser$add_argument("--up_fill_color", type="character", default="#00007F", help="Fill color for up-regulated genes.")
parser$add_argument("--down_fill_color", type="character", default="#B22222", help="Fill color for down-regulated genes.")
parser$add_argument("--ns_fill_color", type="character", default="#BEBEBE", help="Fill color for non-significant genes.")
parser$add_argument("--shape", type="numeric", default=1, help="Shape of the points in the plot. Default: 1.")
parser$add_argument("--size", type="numeric", default=1.8, help="Size of the points in the plot.")
parser$add_argument("--opacity", type="numeric", default=0.8, help="Opacity of the points in the plot.")
parser$add_argument("--legend_title_size", type="numeric", default=8, help="Size of the legend title.")
parser$add_argument("--legend_text_size", type="numeric", default=7, help="Size of the legend text.")
parser$add_argument("--label_top_n_significant", type="integer", default=5, help="Number of top significant genes to label.")
parser$add_argument("--legend_position", type="character", default="right", help="Position of the legend: 'right', 'bottom', 'left', or 'top'.")
parser$add_argument("--is_show_border", type="logical", default=TRUE, help="Whether to show the border of the plot.")
parser$add_argument("--font_size", type="numeric", default=7, help="Font size for the plot text.")
parser$add_argument("--width", type="numeric", default=800, help="Width of the output image (default: 800, unit: pixels).")
parser$add_argument("--height", type="numeric", default=600, help="Height of the output image (default: 600, unit: pixels).")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

# --- Generate volcano plot ---
res_df <- as.data.frame(deg)
res_df$gene <- rownames(res_df)

if (args$is_use_padj) {
    res_df$pvalue_for_plot <- res_df$adj.P.Val
} else {
    res_df$pvalue_for_plot <- res_df$P.Value
}

# Classify genes by thresholds
res_df$group <- "NS"
res_df$group[which(res_df$logFC > args$log2fc_threshold & res_df$pvalue_for_plot < args$pvalue_threshold)] <- "Up"
res_df$group[which(res_df$logFC < -args$log2fc_threshold & res_df$pvalue_for_plot < args$pvalue_threshold)] <- "Down"

# Extract top-N significant genes for labeling
# If label_top_n_significant == 0, the user explicitly requests no labels
# If label_top_n_significant > 0, label the specified number of significant genes
if (args$label_top_n_significant == 0) {
  # No labels requested; create an empty but correctly structured data.frame
  topN <- data.frame(gene = character(0), logFC = numeric(0), pvalue_for_plot = numeric(0), group = character(0))
} else if (args$label_top_n_significant > 0 && sum(res_df$group != "NS") > 0) {
  # Get significant genes and sort by P value
  significant_genes <- res_df %>%
    filter(group != "NS") %>%
    arrange(pvalue_for_plot)
  
  # Take the top N; N cannot exceed the number of significant genes available
  n_to_label <- min(args$label_top_n_significant, nrow(significant_genes))
  topN <- significant_genes %>% slice_head(n = n_to_label)
} else {
  # No significant genes to label; create an empty but correctly structured data.frame
  topN <- data.frame(gene = character(0), logFC = numeric(0), pvalue_for_plot = numeric(0), group = character(0))
}

# plot volcano plot
p <- ggplot(res_df, aes(x = logFC, y = -log10(pvalue_for_plot), color = group)) +
  geom_point(alpha = args$opacity, size = args$size, shape = args$shape) +
  scale_color_manual(values = c("Up" = args$up_fill_color, "Down" = args$down_fill_color, "NS" = args$ns_fill_color)) +
  geom_text(data = topN, aes(label = gene), vjust = 1.5, size = 2.5, show.legend = FALSE) +
  geom_vline(xintercept = c(-1, 1), linetype = "dashed", color = "black") +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "black") +
  labs(title = args$main_title, x = args$x_axis_title, y = args$y_axis_title)

p <- p + theme_minimal(base_size = args$font_size) +
  theme(
    plot.title = element_text(size = args$font_size + 3, hjust = 0.5, face = "bold"),
    axis.title = element_text(size = args$font_size + 1, face="bold"),
    axis.text = element_text(size = args$font_size),
    legend.title = element_text(size = args$legend_title_size, face = "bold"),
    legend.text = element_text(size = args$legend_text_size),
    legend.position = args$legend_position,
    panel.border = if (args$is_show_border) element_rect(colour = "black", fill = NA, linewidth = 0.5) else element_blank(),
    panel.grid.major = element_line(colour = "grey90"), 
    panel.grid.minor = element_line(colour = "grey95") 
  )

# Apply axis limits
x_lim_to_apply <- NULL
if (!args$is_x_axis_auto) {
  x_lim_to_apply <- c(args$x_axis_low, args$x_axis_high)
}
y_lim_to_apply <- NULL
if (!args$is_y_axis_auto) { 
  y_lim_to_apply <- c(args$y_axis_low, args$y_axis_high)
}
if (!is.null(x_lim_to_apply) || !is.null(y_lim_to_apply)) {
  p <- p + coord_cartesian(xlim = x_lim_to_apply, ylim = y_lim_to_apply, expand = TRUE)
}

ggsave(
  filename = args$output_png,
  plot = p,
  width = args$width,
  height = args$height,
  units = "px",
  dpi = 300 # Standard dpi for publication quality
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = p,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

# --- 6. Save data ---
if (!is.null(args$output_csv) && nzchar(trimws(args$output_csv))) {
  tryCatch({
    write.csv(res_df, file = args$output_csv, row.names = FALSE)
  }, error = function(e) {
    warning(paste("Failed to save CSV file to:", args$output_csv, "\nError:", errorMessage(e)))
  })
}