#!/usr/bin/env Rscript

library(dplyr)
library(ggplot2)
library(clusterProfiler)
library(org.Hs.eg.db)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Generate a bar plot for GO enrichment analysis.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input GO enrichment result object (e.g., ego.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to the output PNG file.")
parser$add_argument("--output_csv", type="character", required=TRUE, help="Path to the output CSV file for plot data.")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--is_use_padj", type="logical", default=TRUE, help="Whether to use adjusted p-values (default: TRUE).")
parser$add_argument("--log2fc_threshold", type="numeric", default=1, help="Log2 fold change threshold for significance (default: 1).")
parser$add_argument("--pvalue_threshold", type="numeric", default=0.05, help="P-value threshold for significance (default: 0.05).")
parser$add_argument("--top_n", type="integer", default=10, help="Number of top GO terms to plot. Default is 10.")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Whether to show legend. Default is TRUE.")
parser$add_argument("--legend_title_size", type="integer", default=10, help="Font size for legend title. Default is 10.")
parser$add_argument("--legend_text_size", type="integer", default=10, help="Font size for legend text. Default is 10.")
parser$add_argument("--legend_position", type="character", default="right", help="Position of the legend (e.g., 'right', 'bottom'). Default is 'right'.")
parser$add_argument("--main_title", type="character", default="GO Enrichment Analysis", help="Main title for the plot. Default is 'GO Enrichment Analysis'.")
parser$add_argument("--x_axis_title", type="character", default="-log10(adj. P-value)", help="Title for the x-axis. Default is '-log10(adj. P-value)'.")
parser$add_argument("--y_axis_title", type="character", default=NULL, help="Title for the y-axis. Default is NULL.")
parser$add_argument("--main_title_size", type="integer", default=12, help="Font size for the main title. Default is 12.")
parser$add_argument("--axis_title_size", type="integer", default=10, help="Font size for axis titles. Default is 10.")
parser$add_argument("--axis_text_size", type="integer", default=10, help="Font size for axis text. Default is 10.")
parser$add_argument("--BP_fill_color", type="character", default="#00AFBB", help="Fill color for Biological Process (BP). Default is '#00AFBB'.")
parser$add_argument("--CC_fill_color", type="character", default="#B40426", help="Fill color for Cellular Component (CC). Default is '#B40426'.")
parser$add_argument("--MF_fill_color", type="character", default="#3B4CC0", help="Fill color for Molecular Function (MF). Default is '#3B4CC0'.")
parser$add_argument("--border_color", type="character", default="black", help="Border color for all GO categories. Default is 'black'.")
parser$add_argument("--border_size", type="double", default=1.5, help="Border size for all GO categories. Default is 1.5.")
parser$add_argument("--is_show_border", type="logical", default=TRUE, help="Whether to show border. Default is TRUE.")
parser$add_argument("--width", type="double", default=800, help="Width of the output plot. unit px. Default is 800.")
parser$add_argument("--height", type="double", default=600, help="Height of the output plot. unit px. Default is 600.")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("deg")) {
  stop("The GO enrichment results object 'deg' does not exist in the provided RDA file.")
}

logFC_cut <- args$log2fc_threshold
pval_cut <- args$pvalue_threshold
if (args$is_use_padj) {
  k1 <- deg$adj.P.Val < pval_cut & deg$logFC < -logFC_cut
  k2 <- deg$adj.P.Val < pval_cut & deg$logFC > logFC_cut
} else {
  k1 <- deg$P.Value < pval_cut & deg$logFC < -logFC_cut
  k2 <- deg$P.Value < pval_cut & deg$logFC > logFC_cut
}
deg$change <- ifelse(k1, "down", ifelse(k2, "up", "stable"))
deg <- deg %>% filter(change != "stable")

ego <- enrichGO(
  gene          = deg$ENTREZID,
  OrgDb         = org.Hs.eg.db,
  ont           = "ALL",           # Options: 'BP' / 'CC' / 'MF' / 'ALL'
  pAdjustMethod = "BH",
  pvalueCutoff  = 0.05,
  qvalueCutoff  = 0.05,
  readable      = TRUE
)
# 2) For each ONTOLOGY, sort by p.adjust (ascending) and convert Description to an ordered factor
ego_df <- ego@result %>%
  filter(ONTOLOGY %in% c("BP","CC","MF")) %>%
  group_by(ONTOLOGY) %>%
  slice_min(order_by = p.adjust, n = args$top_n, with_ties = FALSE) %>%
  arrange(p.adjust) %>%
  mutate(Description = factor(Description, levels = unique(Description))) %>%
  ungroup()

# --- Additional check: if no GO results remain, generate a blank plot with a message ---
if (nrow(ego_df) == 0) {
  warning("No GO terms found after enrichment and filtering. Generating a blank plot with a message.")
  p <- ggplot() +
    annotate("text", x = 0.5, y = 0.5, label = "No significant GO terms found based on current criteria.\nPlease check enrichment parameters (p-value/q-value, top_n).",
             size = 5, color = "red", hjust = 0.5, vjust = 0.5) +
    theme_void() +
    labs(title = "GO Enrichment Analysis Result")

  ggsave(
    filename = args$output_png,
    plot = p,
    width = args$width,
    height = args$height,
    units = "px",
    dpi = 300
  )
  # Save an empty CSV for consistency if no data
  write.csv(data.frame(), file = args$output_csv, row.names = FALSE)
  quit(save = "no") # Exit the script gracefully
}

# 3) Plot: map x to -log10(p.adjust)
# Set bar borders based on the is_show_border parameter
if (args$is_show_border) {
  geom_col_params <- list(
    show.legend = args$is_show_legend,
    color = args$border_color,
    linewidth = args$border_size
  )
} else {
  geom_col_params <- list(
    show.legend = args$is_show_legend
  )
}

p <- ggplot(ego_df, aes(x = -log10(p.adjust), y = Description, fill = ONTOLOGY)) +
  do.call(geom_col, geom_col_params) +
  facet_grid(
    ONTOLOGY ~ .,
    scales = "free_y",
    space   = "free",
  ) +
  # Keep bars flush to x = 0
  scale_x_continuous(expand = expansion(mult = c(0, 0.1))) +
  scale_fill_manual(
    values = c(
      BP = args$BP_fill_color,
      CC = args$CC_fill_color,
      MF = args$MF_fill_color
    ),
    guide = if (args$is_show_legend) guide_legend() else "none"
  ) +
  labs(
    x = args$x_axis_title,
    y = args$y_axis_title,
    fill = "Ontology",
    title = args$main_title
  ) +
  # Theme styling
  theme_minimal(base_size = 8) +
  theme(
    strip.placement  = "outside",
    # ---- Style the right-side facet strips ----
    strip.background.y   = element_rect(
      fill   = "grey95",  # background
      colour = "black",   # border
      size   = 0.5         # border width
    ),
    strip.text.y        = element_text(
      angle  = 0,         # horizontal text
      hjust  = 0.5,       # horizontal centering
      vjust  = 0.5,       # vertical centering
      size   = 8,         # font size
      face   = "bold"     # bold
    ),
    plot.title = element_text(size = args$main_title_size, face = "bold", hjust = 0.5),
    axis.title = element_text(size = args$axis_title_size, face = "bold"),
    axis.text = element_text(size = args$axis_text_size),
    legend.title = element_text(size = args$legend_title_size, face = "bold"),
    legend.text = element_text(size = args$legend_text_size),
    legend.position = if (args$is_show_legend) args$legend_position else "none",
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.major.y = element_blank(),
    panel.border = element_rect( # Panel border (separate from bar borders)
      colour = "black", # could be made configurable if needed
      fill = NA,
      linewidth = 1
    ),
  )

# --- 5. Save outputs ---
ggsave(
  filename = args$output_png,
  plot = p,
  width = args$width,
  height = args$height,
  units = "px",
  dpi = 300
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = p,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

# --- 6. Save plot data to CSV ---
write.csv(ego_df, file = args$output_csv, row.names = FALSE)
