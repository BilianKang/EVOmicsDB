#!/usr/bin/env Rscript

library(tidyverse)
library(limma)
library(pheatmap)
library(argparse)

parser <- ArgumentParser(description="Generate a heatmap from differential expression analysis results.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input deg object in RDA format (e.g., DEG.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to save the heatmap (e.g., heatmap_output.png).")
parser$add_argument("--output_csv", type="character", required=FALSE, help="Path to save the heatmap data to a CSV file (e.g., heatmap_data.csv).")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--is_use_padj", type="logical", default=TRUE, help="Whether to use adjusted p-values (default: TRUE).")
parser$add_argument("--log2fc_threshold", type="numeric", default=1, help="Log2 fold change threshold for significance (default: 1).")
parser$add_argument("--pvalue_threshold", type="numeric", default=0.05, help="P-value threshold for significance (default: 0.05).")
parser$add_argument("--top_n", type="numeric", default=10, help="Top N molecular IDs used in the analysis (default: 10).")
parser$add_argument("--title_text", type="character", default="Differentially Expressed Genes Heatmap", help="Title of the heatmap (default: Differentially Expressed Genes Heatmap).")
parser$add_argument("--col_label_size", type="numeric", default=10, help="Font size of the column labels (default: 10).")
parser$add_argument("--row_label_size", type="numeric", default=10, help="Font size of the row labels (default: 10).")
parser$add_argument("--is_col_clustering", type="logical", default=TRUE, help="Whether to perform clustering on columns (default: TRUE).")
parser$add_argument("--is_row_clustering", type="logical", default=TRUE, help="Whether to perform clustering on rows (default: TRUE).")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Whether to show the legend (default: TRUE).")
parser$add_argument("--legend_title", type="character", default="Sample Group", help="Title of the legend (default: Sample Group).")
parser$add_argument("--normal_fill_color", type="character", default="#3B4CC0", help="Colors for top annotations (default: #3B4CC0).")
parser$add_argument("--tumor_fill_color", type="character", default="#B40426", help="Colors for bottom annotations (default: #B40426).")
parser$add_argument("--color_scheme_low", type="character", default="navy", help="Color scheme for heatmap (default: navy).")
parser$add_argument("--color_scheme_mid", type="character", default="white", help="Color scheme for heatmap (default: white).")
parser$add_argument("--color_scheme_high", type="character", default="red", help="Color scheme for heatmap (default: red).")
parser$add_argument("--width", type="numeric", default=800, help="Width of the output image (default: 800, unit: pixels).")
parser$add_argument("--height", type="numeric", default=600, help="Height of the output image (default: 600, unit: pixels).")
parser$add_argument("--font_size", type="numeric", default=10, help="Font size for labels (default: 10, unit: points).") # Not used yet; clarify how to apply it
parser$add_argument("--angle_col", type="numeric", default=0, help="Angle of the column labels (default: 0).")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

## Mark up-/down-regulated genes
if (args$is_use_padj) {
  p_val_col_name <- "adj.P.Val"
} else {
  p_val_col_name <- "P.Value"
}

k1 <- (deg[[p_val_col_name]] < args$pvalue_threshold) & (deg$logFC < -args$log2fc_threshold)
k2 <- (deg[[p_val_col_name]] < args$pvalue_threshold) & (deg$logFC > args$log2fc_threshold)
deg$change <- ifelse(k1, "down", ifelse(k2, "up", "stable"))

## Heatmap ##
# Filter for significantly changed genes first
sig_deg_candidates <- deg[deg$change != "stable", ]

cg <- c() # Initialize cg as an empty vector

if (nrow(sig_deg_candidates) > 0) {
  # Order these candidates by the chosen p-value type, then by absolute logFC as a tie-breaker
  if (args$is_use_padj) {
    sig_deg_ordered <- sig_deg_candidates[order(sig_deg_candidates$adj.P.Val, -abs(sig_deg_candidates$logFC)), ]
  } else {
    sig_deg_ordered <- sig_deg_candidates[order(sig_deg_candidates$P.Value, -abs(sig_deg_candidates$logFC)), ]
  }

  # Select top N genes
  num_sig_genes <- nrow(sig_deg_ordered)
  actual_top_n <- min(args$top_n, num_sig_genes)
  
  if (actual_top_n > 0) {
    top_n_deg <- head(sig_deg_ordered, actual_top_n)
    cg <- rownames(top_n_deg)
  } else {
    warning(paste0("top_n is ", args$top_n, ", but after filtering and ordering, no genes were selected for the heatmap from ", num_sig_genes, " significant genes. Output might be empty."))
  }
} else {
  warning("No significant genes found with the given thresholds. Heatmap will be empty or show a message.")
}

# Subset expression data for selected genes
# Use drop = FALSE to ensure `diff` remains a matrix even if only one gene/sample is selected.
diff <- exp[cg, , drop = FALSE]
group_list <- ifelse(substr(colnames(exp), 1, 1) == "N", "normal", "tumor")
group_list <- factor(group_list, levels = c("normal", "tumor"))
annotation_col <- data.frame(group = group_list)
rownames(annotation_col) <- colnames(diff)

# Custom annotation colors
ann_colors <- list(
  group = c(
    normal = args$normal_fill_color,
    tumor  = args$tumor_fill_color
  )
)

plot_heatmap <- function() {
  pheatmap(
    mat = diff,
    annotation_col = annotation_col,
    annotation_colors = ann_colors,
    scale = "row",                    # Row scaling (z-score)
    clustering_method = "complete",   # Clustering method
    cluster_rows = args$is_row_clustering,
    cluster_cols = args$is_col_clustering,
    show_rownames = TRUE,
    show_colnames = TRUE,
    color = colorRampPalette(c(args$color_scheme_low, args$color_scheme_mid, args$color_scheme_high))(50),
    fontsize = args$font_size,
    fontsize_row = args$row_label_size,
    fontsize_col = args$col_label_size,
    legend = args$is_show_legend,
    legend_main_title = args$legend_title,
    angle_col = args$angle_col,
    main = args$title_text
  )
}

# Save as PNG
if (nrow(diff) == 0 || all(is.na(diff))) {
  png(args$output_png, width = args$width, height = args$height, res = 300)
  plot.new()
  text(0.5, 0.5, "No significant genes to display", cex = 1.5)
  dev.off()
  quit(status = 0)
}
png(args$output_png, width = args$width, height = args$height, res = 300)
plot_heatmap()
dev.off()

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  pdf(
    file = args$output_pdf,
    width = args$width / 300,
    height = args$height / 300
  )
  plot_heatmap()
  dev.off()
}

# --- 6. Save heatmap data to CSV (if output_csv is provided) ---
if (!is.null(args$output_csv) && nzchar(args$output_csv)) {
  if (nrow(diff) > 0) {
    write.csv(diff, file = args$output_csv, row.names = TRUE, quote = TRUE)
  } else {
    warning(paste("No data to save to CSV as no significant genes were selected for the heatmap. CSV file '", args$output_csv, "' will not be created or will be empty.", sep=""))
  }
}