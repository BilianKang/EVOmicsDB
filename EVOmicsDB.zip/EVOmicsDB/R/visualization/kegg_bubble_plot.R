#!/usr/bin/env Rscript

library(dplyr)
library(ggplot2)
library(clusterProfiler)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Generate a bar plot for KEGG enrichment analysis.")
parser$add_argument("--input_rda", type="character", required=TRUE, help="Path to the input KEGG enrichment result object (e.g., kk.rda).")
parser$add_argument("--output_png", type="character", required=TRUE, help="Path to the output PNG file.")
parser$add_argument("--output_csv", type="character", required=TRUE, help="Path to the output CSV file for plot data.")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--is_use_padj", type="logical", default=TRUE, help="Whether to use adjusted p-values (default: TRUE).")
parser$add_argument("--log2fc_threshold", type="numeric", default=1, help="Log2 fold change threshold for significance (default: 1).")
parser$add_argument("--pvalue_threshold", type="numeric", default=0.05, help="P-value threshold for significance (default: 0.05).")
parser$add_argument("--top_n", type="integer", default=10, help="Number of top KEGG terms to plot. Default is 10.")
parser$add_argument("--is_show_legend", type="logical", default=TRUE, help="Whether to show legend. Default is TRUE.")
parser$add_argument("--legend_title_size", type="integer", default=10, help="Font size for legend title. Default is 10.")
parser$add_argument("--legend_text_size", type="integer", default=10, help="Font size for legend text. Default is 10.")
parser$add_argument("--legend_position", type="character", default="right", help="Position of the legend (e.g., 'right', 'bottom'). Default is 'right'.")
parser$add_argument("--main_title", type="character", default="KEGG Enrichment Analysis", help="Main title for the plot. Default is 'KEGG Enrichment Analysis'.")
parser$add_argument("--x_axis_title", type="character", default="-log10(adj. P-value)", help="Title for the x-axis. Default is '-log10(adj. P-value)'.")
parser$add_argument("--y_axis_title", type="character", default=NULL, help="Title for the y-axis. Default is NULL.")
parser$add_argument("--main_title_size", type="integer", default=12, help="Font size for the main title. Default is 12.")
parser$add_argument("--axis_title_size", type="integer", default=10, help="Font size for axis titles. Default is 10.")
parser$add_argument("--axis_text_size", type="integer", default=10, help="Font size for axis text. Default is 10.")
parser$add_argument("--low_fill_color", type="character", default="#00AFBB", help="Fill color for low. Default is '#00AFBB'.")
parser$add_argument("--high_fill_color", type="character", default="#B40426", help="Fill color for high. Default is '#B40426'.")
parser$add_argument("--border_color", type="character", default="black", help="Border color for all KEGG categories. Default is 'black'.")
parser$add_argument("--border_size", type="double", default=1.5, help="Border size for all KEGG categories. Default is 1.5.")
# Auto-detect ID type from row names
parser$add_argument("--width", type="double", default=800, help="Width of the output plot. unit px. Default is 800.")
parser$add_argument("--height", type="double", default=600, help="Height of the output plot. unit px. Default is 600.")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("deg")) {
  stop("The KEGG enrichment results object 'deg' does not exist in the provided RDA file.")
}

logFC_cut <- args$log2fc_threshold
pval_cut <- args$pvalue_threshold
if (args$is_use_padj) {
  k1 <- deg$adj.P.Val < pval_cut & deg$logFC < -logFC_cut
  k2 <- deg$adj.P.Val < pval_cut & deg$logFC > logFC_cut
} else {
  k1 <- deg$P.Value < pval_cut & deg$logFC < -logFC_cut
  k2 <- deg$P.Value < pval_cut & deg$logFC > logFC_cut
}
deg$change <- ifelse(k1, "down", ifelse(k2, "up", "stable"))
deg <- deg %>% filter(change != "stable")

kk <- enrichKEGG(
  gene         = deg$ENTREZID,
  organism     = "hsa",
  pAdjustMethod= "BH",
  pvalueCutoff = 0.05,
  qvalueCutoff = 0.05
)


kegg_df <- kk@result %>%
  arrange(p.adjust) %>%
  slice_min(order_by = p.adjust, n = args$top_n) %>%
  mutate(Description = factor(Description, levels = rev(unique(Description))))  # Reverse factor levels so the most significant terms appear at the top

# --- Safety check: if no KEGG terms are available, generate a text-only plot ---
if (nrow(kegg_df) == 0) {
  warning("No KEGG terms found after enrichment and filtering. Generating a blank plot with a message.")
  p <- ggplot() +
    annotate("text", x = 0.5, y = 0.5, label = "No significant KEGG terms found based on current criteria.\nPlease check enrichment parameters (p-value/q-value, top_n).",
             size = 5, color = "red", hjust = 0.5, vjust = 0.5) +
    theme_void() +
    labs(title = "KEGG Enrichment Analysis Result")

  ggsave(
    filename = args$output_png,
    plot = p,
    width = args$width,
    height = args$height,
    units = "px",
    dpi = 300
  )
  # Save an empty CSV for consistency if no data
  write.csv(data.frame(), file = args$output_csv, row.names = FALSE)
  quit(save = "no") # Exit the script gracefully
}

# 2) Bubble plot: x = -log10(p.adjust); bubble size = Count; color = p.adjust
point_border_color <- if(args$is_show_border) args$border_color else NA_character_ # NA for transparent border
point_stroke_size <- if(args$is_show_border) args$border_size else 0

p <- ggplot(kegg_df, aes(x = -log10(p.adjust), y = Description)) +
  geom_point(aes(size = Count, fill = -log10(p.adjust)), 
             shape = 21, color = point_border_color, alpha = 0.8, stroke = point_stroke_size) +
  scale_fill_gradient(
    low = args$low_fill_color, high = args$high_fill_color, 
    name = "-log10(adj. P-value)"
  ) +
  scale_size(range = c(3, 8)) +
  scale_x_continuous(expand = expansion(mult = c(0.1, 0.1))) +
  scale_y_discrete(expand = expansion(add = c(0.5, 0.5))) + 
  labs(
    x = args$x_axis_title,
    y = args$y_axis_title,
    size  = "Gene Count",
    title = args$main_title
  ) +
  theme_minimal(base_size = 8) +
  theme(
    plot.title = element_text(size = args$main_title_size, face = "bold", hjust = 0.5),
    axis.title = element_text(size = args$axis_title_size, face = "bold"),
    axis.text = element_text(size = args$axis_text_size),
    legend.title = element_text(size = args$legend_title_size, face = "bold"),
    legend.text = element_text(size = args$legend_text_size),
    legend.position = if (args$is_show_legend) args$legend_position else "none",
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.major.y = element_blank(),
    panel.border = element_rect(
      colour = "black",
      fill   = NA,
      size   = 0.5
    )
  )

# --- 5. Save figure ---
ggsave(
  filename = args$output_png,
  plot = p,
  width = args$width,
  height = args$height,
  units = "px",
  dpi = 300
)

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  ggsave(
    filename = args$output_pdf,
    plot = p,
    width = args$width / 300,
    height = args$height / 300,
    units = "in",
    device = cairo_pdf
  )
}

# --- 4. Save plotting data to CSV ---
if (!is.null(args$output_csv) && nrow(kegg_df) > 0) {
  write.csv(kegg_df, args$output_csv, row.names = FALSE, quote = TRUE)
}
