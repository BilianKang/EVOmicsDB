#!/usr/bin/env Rscript

# ============================================================
# lncrna_target_network.r
# lncRNA target intersection network
# Supported pairs: lncRNA+mRNA, lncRNA+miRNA, lncRNA+protein
# Based on the backbone reference database: master_lncRNA_target_database.csv
# ============================================================

library(dplyr)
library(scales)
library(visNetwork)
library(jsonlite)
library(stringr)
library(argparse)
library(igraph)

# --- Get script path ---
get_script_path <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  script_path <- sub(file_arg, "", args[grep(file_arg, args)])
  return(normalizePath(script_path))
}

script_dir <- dirname(get_script_path())
master_lnc_targets_path <- file.path(script_dir, "../../../db/rda/master_lncRNA_target_database.csv")

# --- Command-line arguments ---
parser <- ArgumentParser(description = "Build lncRNA target intersection network")
parser$add_argument("--lncrna_dataset", type = "character", required = TRUE, help = "Path to lncRNA dataset file")
parser$add_argument("--target_dataset", type = "character", required = TRUE, help = "Path to target dataset file (mRNA/miRNA/Protein)")
parser$add_argument("--target_type", type = "character", required = TRUE, help = "Target type: mRNA/miRNA/Protein")
parser$add_argument("--min_degree", type = "integer", default = 5, help = "Minimum node degree to keep")
parser$add_argument("--keep_target_classes", type = "character", default = "miRNA,gene_protein", help = "Target classes to keep (comma-separated)")
parser$add_argument("--output_html", type = "character", required = TRUE, help = "Output HTML file path")
parser$add_argument("--output_csv", type = "character", required = TRUE, help = "Output CSV file path")
# lncRNA p-value parameters
parser$add_argument("--lncrna_is_use_padj", type = "logical", default = TRUE, help = "Whether to use adjusted p-value for lncRNA")
parser$add_argument("--lncrna_pvalue", type = "double", default = 0.05, help = "P-value threshold for lncRNA")
# Target p-value parameters
parser$add_argument("--target_is_use_padj", type = "logical", default = TRUE, help = "Whether to use adjusted p-value for target")
parser$add_argument("--target_pvalue", type = "double", default = 0.05, help = "P-value threshold for target")
# Titles
parser$add_argument("--main_title", type = "character", default = "lncRNA Target Network", help = "Main title")
parser$add_argument("--main_title_size", type = "integer", default = 14, help = "Main title font size")
parser$add_argument("--axis_text_size", type = "integer", default = 10, help = "Node label font size")
# logFC color mapping parameters
parser$add_argument("--low_color", type = "character", default = "#1f78b4", help = "Color for low logFC (downregulated)")
parser$add_argument("--mid_color", type = "character", default = "white", help = "Color for zero logFC")
parser$add_argument("--high_color", type = "character", default = "#e31a1c", help = "Color for high logFC (upregulated)")
# Node shapes
parser$add_argument("--lncrna_shape", type = "character", default = "dot", help = "Shape for lncRNA nodes")
parser$add_argument("--target_shape", type = "character", default = "diamond", help = "Shape for target nodes (mRNA/miRNA/Protein)")
# Legend
parser$add_argument("--is_show_legend", type = "character", default = "TRUE", help = "Show legend (TRUE/FALSE)")
parser$add_argument("--legend_title_size", type = "integer", default = 10, help = "Legend title font size")
parser$add_argument("--legend_position", type = "character", default = "right", help = "Legend position")
# Export settings
parser$add_argument("--width", type = "integer", default = 1200, help = "Output width (px)")
parser$add_argument("--height", type = "integer", default = 800, help = "Output height (px)")
args <- parser$parse_args()

# Parse keep_target_classes
keep_target_classes <- unlist(strsplit(args$keep_target_classes, ","))

# Parse boolean arguments
show_legend <- toupper(args$is_show_legend) == "TRUE"

# ======================== Helper functions ========================

# Generate an error HTML page
# Generate an error HTML page
generate_error_html <- function(output_html, error_message, title = "Analysis Failed") {
  html_content <- sprintf('<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>%s</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background-color: #f9fafb;
      color: #111827;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }
    .error-container {
      background-color: #ffffff;
      padding: 2rem;
      border: 1px solid #e5e7eb;
      border-radius: 0.5rem;
      max-width: 32rem;
      width: 100%%;
      box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
    }
    .error-title {
      font-size: 1.125rem;
      font-weight: 600;
      color: #ef4444;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .error-message {
      background-color: #fef2f2;
      border: 1px solid #fee2e2;
      color: #991b1b;
      padding: 1rem;
      border-radius: 0.375rem;
      font-size: 0.875rem;
      line-height: 1.5;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      word-break: break-word;
      white-space: pre-wrap;
    }
    .suggestion {
      margin-top: 1.5rem;
      font-size: 0.875rem;
      color: #6b7280;
    }
  </style>
</head>
<body>
  <div class="error-container">
    <div class="error-title">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
      %s
    </div>
    <div class="error-message">%s</div>
    <div class="suggestion">Please adjust your parameters and try again.</div>
  </div>
</body>
</html>', title, title, error_message)
  
  writeLines(html_content, output_html)
  cat("  [Error HTML] Generated error page:", output_html, "\n")
}

# stop() wrapper that also writes an error HTML output
stop_with_html <- function(error_message, output_html = NULL) {
  if (!is.null(output_html)) {
    generate_error_html(output_html, error_message)
  }
  stop(error_message)
}

get_significant <- function(df, pvalue_threshold = 0.05, is_use_padj = TRUE) {
  # Use adj.P.Val or P.Value depending on is_use_padj
  if (is_use_padj && "adj.P.Val" %in% colnames(df)) {
    df %>% dplyr::filter(adj.P.Val < pvalue_threshold)
  } else {
    df %>% dplyr::filter(P.Value < pvalue_threshold)
  }
}

# ======================== Main workflow ========================

cat("[lncRNA Network] lncRNA +", args$target_type, " regulatory network (showing intersection targets only)...\n")

# ======================== RDA loader ========================

read_deg_from_rda <- function(rda_file, output_html = NULL) {
  env <- new.env()
  load(rda_file, envir = env)
  if (!exists("deg", envir = env)) {
    stop_with_html(paste("deg object not found in", rda_file), output_html)
  }
  df <- env$deg
  df$ID <- rownames(df)
  return(df)
}

# Load the master_lnc_targets database
if (!file.exists(master_lnc_targets_path)) {
  stop_with_html(paste("Master lncRNA targets database not found at:", master_lnc_targets_path), args$output_html)
}
master_lnc_targets <- read.csv(master_lnc_targets_path, stringsAsFactors = FALSE)
cat("  Master database loaded successfully, total", nrow(master_lnc_targets), "records\n")

# Read differential expression results (from the RDA file)
lnc_sig <- read_deg_from_rda(args$lncrna_dataset, args$output_html)
other_sig <- read_deg_from_rda(args$target_dataset, args$output_html)

# Filter by P value / FDR
lnc_sig <- get_significant(lnc_sig, args$lncrna_pvalue, args$lncrna_is_use_padj)
other_sig <- get_significant(other_sig, args$target_pvalue, args$target_is_use_padj)

## 1. Get differential lncRNA IDs
if ("lncRNA" %in% colnames(lnc_sig)) {
  lnc_id_col <- "lncRNA"
} else if ("ID" %in% colnames(lnc_sig)) {
  lnc_id_col <- "ID"
    } else {
  stop_with_html("Cannot find lncRNA or ID column in lnc_sig, please check column names.", args$output_html)
}
lnc_list <- unique(lnc_sig[[lnc_id_col]])
lnc_list <- lnc_list[!is.na(lnc_list) & lnc_list != ""]

if (length(lnc_list) == 0) {
  stop_with_html("No differentially expressed lncRNA found, skipping network construction.", args$output_html)
}
cat("  Number of differentially expressed lncRNA:", length(lnc_list), "\n")

## 2. IDs from the paired omics layer
if ("ID" %in% colnames(other_sig)) {
  other_id_col <- "ID"
} else if (args$target_type == "miRNA" && "miRNA" %in% colnames(other_sig)) {
  other_id_col <- "miRNA"
} else {
  stop_with_html("Cannot find ID (or miRNA) column in other_sig, please check.", args$output_html)
}
other_ids <- unique(other_sig[[other_id_col]])
other_ids <- other_ids[!is.na(other_ids) & other_ids != ""]
cat("  Number of differentially expressed", args$target_type, ":", length(other_ids), "\n")

## 3. Extract targets of differential lncRNAs from master_lnc_targets
network_df0 <- master_lnc_targets %>%
  dplyr::filter(lncRNA %in% lnc_list) %>%
  dplyr::select(lncRNA, target, target_type) %>%
  distinct()

if (nrow(network_df0) == 0) {
  stop_with_html("No targets found for these lncRNAs in master_lnc_targets, skipping.", args$output_html)
}
cat("  Number of lnc-target relationships in master table:", nrow(network_df0), "\n")

## 4. Classify target types
network_df <- network_df0 %>%
  mutate(
    class = dplyr::case_when(
      stringr::str_detect(target_type, stringr::regex("miRNA", ignore_case = TRUE))             ~ "miRNA",
      stringr::str_detect(target_type, stringr::regex("protein|pcg|gene|tf", ignore_case = TRUE)) ~ "gene_protein",
      stringr::str_detect(target_type, stringr::regex("RNA",   ignore_case = TRUE))             ~ "RNA",
      stringr::str_detect(target_type, stringr::regex("DNA",   ignore_case = TRUE))             ~ "DNA_TF",
      TRUE ~ "Other"
    )
  ) %>%
  dplyr::filter(class %in% keep_target_classes)

if (nrow(network_df) == 0) {
  stop_with_html("No targets remain after filtering by keep_target_classes, skipping.", args$output_html)
}
cat("  Number of lnc-target relationships after type filtering:", nrow(network_df), "\n")

## 5. Intersect with differential features in the paired omics layer
network_df_int <- network_df %>%
  dplyr::filter(target %in% other_ids)

if (nrow(network_df_int) == 0) {
  stop_with_html(paste("No intersection between lnc predicted targets and differentially expressed", args$target_type, ", network is empty."), args$output_html)
}
cat("  lnc targets ∩ differentially expressed", args$target_type, " size:", nrow(network_df_int), "\n")

## ========= Use a unified logFC range for color mapping =========
if (!"logFC" %in% colnames(lnc_sig)) {
  stop_with_html("lnc_sig is missing logFC column, cannot perform logFC mapping.", args$output_html)
}
if (!"logFC" %in% colnames(other_sig)) {
  stop_with_html("other_sig is missing logFC column, cannot perform logFC mapping.", args$output_html)
}

range_all <- range(c(lnc_sig$logFC, other_sig$logFC), na.rm = TRUE)

## Build a color gradient function (using user-specified colors)
color_palette <- c(args$low_color, args$mid_color, args$high_color)

## Prepare an id-to-logFC table for later joins
lnc_logfc_tbl <- lnc_sig %>%
  dplyr::select(id = dplyr::all_of(lnc_id_col), logFC) %>%
  dplyr::distinct()

other_logfc_tbl <- other_sig %>%
  dplyr::select(id = dplyr::all_of(other_id_col), logFC) %>%
  dplyr::distinct()

## ========= Build nodes & edges =========

# lncRNA nodes
nodes_lnc <- data.frame(
  id    = lnc_list,
  label = lnc_list,
  group = "lncRNA",
  stringsAsFactors = FALSE
) %>%
  dplyr::left_join(lnc_logfc_tbl, by = "id") %>%
  dplyr::mutate(
    color = ifelse(
      is.na(logFC),
      "#bdbdbd",  ## Gray color for nodes without logFC
      scales::col_numeric(
        palette = color_palette,
        domain  = range_all
      )(logFC)
    ),
    value = ifelse(
      is.na(logFC),
      5,                  ## Medium size for nodes without logFC
      abs(logFC) * 5
    ),
    title = ifelse(
      is.na(logFC),
      paste0("lncRNA: ", id, "<br>logFC: NA"),
      paste0("lncRNA: ", id, "<br>logFC: ", round(logFC, 3))
    )
  )

# Target nodes: use target_type as the group (simplified grouping)
nodes_target <- network_df_int %>%
  dplyr::select(id = target) %>%
  dplyr::distinct() %>%
  dplyr::mutate(
    label = id,
    group = args$target_type  # Use target_type (mRNA/miRNA/protein) as the group name
  ) %>%
  dplyr::left_join(other_logfc_tbl, by = "id") %>%
      dplyr::mutate(
    color = ifelse(
      is.na(logFC),
      "#bdbdbd",
      scales::col_numeric(
        palette = color_palette,
        domain  = range_all
      )(logFC)
    ),
    value = ifelse(
      is.na(logFC),
      5,
      abs(logFC) * 5
    ),
    title = ifelse(
      is.na(logFC),
      paste0(args$target_type, ": ", id, "<br>logFC: NA"),
      paste0(args$target_type, ": ", id, "<br>logFC: ", round(logFC, 3))
    )
  )

nodes <- dplyr::bind_rows(nodes_lnc, nodes_target) %>%
  dplyr::distinct(id, .keep_all = TRUE)

edges <- network_df_int %>%
  dplyr::select(from = lncRNA, to = target)

## ========= Degree filtering =========
g <- igraph::graph_from_data_frame(d = edges,
                                   directed = TRUE,
                                   vertices = nodes)

deg <- igraph::degree(g, mode = "all")
keep_ids <- names(deg[deg >= args$min_degree])

if (length(keep_ids) == 0) {
  cat("  [Warning] All node degrees < min_degree, consider lowering min_degree. Not drawing network.\n")
  stop_with_html(paste0("All node degrees are less than min_degree (", args$min_degree, "), cannot construct network. Please try lowering the min_degree parameter."), args$output_html)
}

nodes_filt <- nodes %>%
  dplyr::filter(id %in% keep_ids)

edges_filt <- edges %>%
  dplyr::filter(from %in% keep_ids, to %in% keep_ids)

cat("  After degree filtering: nodes", nrow(nodes_filt), ", edges", nrow(edges_filt), "\n")

## ========= Build the network visualization =========
net <- visNetwork::visNetwork(nodes_filt, edges_filt,
                      main = list(text = args$main_title, 
                                  style = paste0("font-size:", args$main_title_size, "px;font-weight:bold;")),
                      width = paste0(args$width, "px"),
                      height = paste0(args$height, "px")) %>%
  visNetwork::visNodes(
    font    = list(face = "arial", size = args$axis_text_size),
    scaling = list(min = 5, max = 40)   ## Let value have more noticeable size differences
  ) %>%
  visNetwork::visEdges(smooth = FALSE) %>%
  ## Only define two groups: lncRNA and target_type (using user-specified shapes)
  visNetwork::visGroups(groupname = "lncRNA", shape = args$lncrna_shape) %>%
  visNetwork::visGroups(groupname = args$target_type, shape = args$target_shape) %>%
  visNetwork::visOptions(
    highlightNearest = list(enabled = TRUE, degree = 1, hover = TRUE),
    nodesIdSelection = TRUE,
    selectedBy       = "group"
  ) %>%
  visNetwork::visLayout(randomSeed = 123)

# Show or hide the legend based on settings
if (show_legend) {
  net <- net %>%
    visNetwork::visLegend(
      useGroups = TRUE,
      position = if (args$legend_position %in% c("left", "right")) args$legend_position else "right",
      main = list(text = "Legend", style = paste0("font-size:", args$legend_title_size, "px;")),
      ncol = 1,
      width = 0.15
    )
}

## ========= Save outputs =========
visNetwork::visSave(net, file = args$output_html)
write.table(
  network_df_int,
  file      = args$output_csv,
  sep       = "\t",
  quote     = FALSE,
  row.names = FALSE
)

cat("  Output file:", args$output_html, "\n")
cat("  Output file:", args$output_csv, "\n")

# Write summary statistics
result <- list(
  lncrna_count = sum(nodes_filt$group == "lncRNA"),
  target_count = sum(nodes_filt$group != "lncRNA"),
  edge_count   = nrow(edges_filt),
  target_type  = args$target_type
)

cat(toJSON(result, auto_unbox = TRUE), "\n")
