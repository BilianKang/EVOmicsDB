#!/usr/bin/env Rscript

# ============================================================
# go_network.r
# GO hierarchical network (mRNA + Protein)
# Three-layer structure: TopCore → SmallCore → GO term
# Supported combination: mRNA + Protein
# ============================================================

library(clusterProfiler)
library(dplyr)
library(scales)
library(visNetwork)
library(org.Hs.eg.db)
library(jsonlite)
library(argparse)

parser <- ArgumentParser(description = "Build GO hierarchical network (mRNA + Protein)")
# Basic parameters
parser$add_argument("--mrna_dataset", type = "character", required = TRUE, help = "Path to mRNA dataset file")
parser$add_argument("--protein_dataset", type = "character", required = TRUE, help = "Path to Protein dataset file")
parser$add_argument("--pvalue_threshold", type = "double", default = 0.05, help = "P-value cutoff")
parser$add_argument("--p_adjust_method", type = "character", default = "BH", help = "P-value adjustment method")
parser$add_argument("--ont", type = "character", default = "ALL", help = "GO ontology: ALL/BP/MF/CC")
parser$add_argument("--output_html", type = "character", required = TRUE, help = "Output HTML file path")
parser$add_argument("--output_csv", type = "character", required = TRUE, help = "Output CSV file path")
# Titles
parser$add_argument("--main_title", type = "character", default = "GO Hierarchical Network", help = "Main title")
parser$add_argument("--main_title_size", type = "integer", default = 14, help = "Main title font size")
parser$add_argument("--axis_text_size", type = "integer", default = 10, help = "Node label font size")
# Nodes (colors)
parser$add_argument("--BP_fill_color", type = "character", default = "#00007F", help = "BP SmallCore fill color")
parser$add_argument("--CC_fill_color", type = "character", default = "#B22222", help = "CC SmallCore fill color")
parser$add_argument("--MF_fill_color", type = "character", default = "#3B4CC0", help = "MF SmallCore fill color")
# GO term node color gradient (mapped by Count)
parser$add_argument("--low_color", type = "character", default = "#deebf7", help = "Low Count color")
parser$add_argument("--mid_color", type = "character", default = "#9ecae1", help = "Mid Count color")
parser$add_argument("--high_color", type = "character", default = "#3182bd", help = "High Count color")
parser$add_argument("--border_color", type = "character", default = "black", help = "Border color")
parser$add_argument("--border_size", type = "double", default = 1.0, help = "Border size")
# TopCore colors
parser$add_argument("--rna_core_color", type = "character", default = "#9467bd", help = "RNA_core color")
parser$add_argument("--protein_core_color", type = "character", default = "#2ca02c", help = "Protein_core color")
parser$add_argument("--common_core_color", type = "character", default = "#d62728", help = "Common_core color")
# Legend
parser$add_argument("--is_show_legend", type = "character", default = "TRUE", help = "Show legend (TRUE/FALSE)")
parser$add_argument("--legend_title_size", type = "integer", default = 10, help = "Legend title font size")
parser$add_argument("--legend_text_size", type = "integer", default = 9, help = "Legend text font size")
parser$add_argument("--legend_position", type = "character", default = "right", help = "Legend position")
# Export settings
parser$add_argument("--is_show_border", type = "character", default = "TRUE", help = "Show border (TRUE/FALSE)")
parser$add_argument("--width", type = "integer", default = 1200, help = "Output width (px)")
parser$add_argument("--height", type = "integer", default = 800, help = "Output height (px)")
args <- parser$parse_args()

# Parse boolean arguments
args$is_show_legend <- toupper(args$is_show_legend) == "TRUE"
args$is_show_border <- toupper(args$is_show_border) == "TRUE"

# ======================== Helper functions ========================

get_significant <- function(df, pvalue_threshold = 0.05) {
  df %>% dplyr::filter(P.Value < pvalue_threshold)
}

map_node_color_by_count <- function(nodes_df,
                                    source_color = "#F5DEB3",
                                    na_color     = "#bdbdbd",
                                    palette_cols = c(args$low_color, args$mid_color, args$high_color)) {
  count_values <- nodes_df$Count[!is.na(nodes_df$Count)]
  if (length(count_values) == 0) {
    return(nodes_df %>% dplyr::mutate(color = na_color))
  }
  
  count_range <- range(count_values, na.rm = TRUE)
  if (diff(count_range) == 0) {
    count_range <- c(count_range[1] - 1e-6, count_range[2] + 1e-6)
  }
  
  col_fun <- scales::col_numeric(
    palette = palette_cols,
    domain  = count_range
  )
  
  nodes_df %>%
    dplyr::mutate(
      color = dplyr::case_when(
        type == "Source"  ~ source_color,
        is.na(Count)      ~ na_color,
        TRUE              ~ col_fun(Count)
      )
    )
}

# ======================== RDA loading function ========================

read_deg_from_rda <- function(rda_file) {
  env <- new.env()
  load(rda_file, envir = env)
  if (!exists("deg", envir = env)) {
    stop(paste("deg object not found in", rda_file))
  }
  df <- env$deg
  df$ID <- rownames(df)
  return(df)
}

# ======================== Main workflow ========================

cat("Building GO hierarchical network: mRNA + Protein\n")
cat("  Ontology:", args$ont, "\n")
cat("  P-value cutoff:", args$pvalue_threshold, "\n")

# Load data (from the RDA file)
mrna_df <- read_deg_from_rda(args$mrna_dataset)
protein_df <- read_deg_from_rda(args$protein_dataset)

mrna_sig <- get_significant(mrna_df, args$pvalue_threshold)
protein_sig <- get_significant(protein_df, args$pvalue_threshold)

cat("  Significant mRNA:", nrow(mrna_sig), "\n")
cat("  Significant Protein:", nrow(protein_sig), "\n")

if (nrow(mrna_sig) == 0 || nrow(protein_sig) == 0) {
  stop("No significant data after filtering")
}

# Gene ID mapping
rna_genes <- mrna_sig$ID
rna_entrez <- bitr(rna_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
if (nrow(rna_entrez) == 0) {
  stop("mRNA genes cannot be mapped to ENTREZID")
}

protein_genes <- protein_sig$ID
protein_entrez <- bitr(protein_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
if (nrow(protein_entrez) == 0) {
  stop("Protein genes cannot be mapped to ENTREZID")
}

# GO enrichment (ont = ALL)
cat("  Running mRNA GO enrichment...\n")
rna_go <- enrichGO(
  gene          = rna_entrez$ENTREZID,
  OrgDb         = org.Hs.eg.db,
  ont           = args$ont,
  pvalueCutoff  = args$pvalue_threshold,
  pAdjustMethod = args$p_adjust_method,
  readable      = TRUE
)
rna_go_df <- as.data.frame(rna_go)
if (nrow(rna_go_df) == 0) {
  stop("mRNA GO enrichment result is empty")
}

cat("  Running Protein GO enrichment...\n")
protein_go <- enrichGO(
  gene          = protein_entrez$ENTREZID,
  OrgDb         = org.Hs.eg.db,
  ont           = args$ont,
  pvalueCutoff  = args$pvalue_threshold,
  pAdjustMethod = args$p_adjust_method,
  readable      = TRUE
)
protein_go_df <- as.data.frame(protein_go)
if (nrow(protein_go_df) == 0) {
  stop("Protein GO enrichment result is empty")
}

cat("  mRNA GO terms:", nrow(rna_go_df), "\n")
cat("  Protein GO terms:", nrow(protein_go_df), "\n")

# Merge GO results (by ID + Description + ONTOLOGY)
go_combined <- dplyr::full_join(
  rna_go_df     %>% dplyr::select(ID, Description, Count, p.adjust, ONTOLOGY),
  protein_go_df %>% dplyr::select(ID, Description, Count, p.adjust, ONTOLOGY),
  by = c("ID", "Description", "ONTOLOGY"),
  suffix = c("_RNA", "_Protein")
) %>%
  dplyr::mutate(
    SourceType = dplyr::case_when(
      !is.na(Count_RNA)  & !is.na(Count_Protein) ~ "Common",
      !is.na(Count_RNA)  &  is.na(Count_Protein) ~ "RNA",
      is.na(Count_RNA)   & !is.na(Count_Protein) ~ "Protein"
    ),
    Count = dplyr::case_when(
      SourceType == "Common"  ~ Count_RNA + Count_Protein,
      SourceType == "RNA"     ~ Count_RNA,
      SourceType == "Protein" ~ Count_Protein
    ),
    p.adjust = dplyr::case_when(
      SourceType == "Common"  ~ pmin(p.adjust_RNA, p.adjust_Protein, na.rm = TRUE),
      SourceType == "RNA"     ~ p.adjust_RNA,
      SourceType == "Protein" ~ p.adjust_Protein
    )
  )

go_combined <- go_combined[!is.na(go_combined$SourceType), ]
if (nrow(go_combined) == 0) {
  stop("No overlapping GO terms between mRNA and Protein")
}

cat("  Combined GO terms:", nrow(go_combined), "\n")

# Save merged GO results table
write.table(
  go_combined,
  file      = args$output_csv,
  sep       = "\t",
  row.names = FALSE,
  quote     = FALSE
)
cat("  Combined GO results saved:", args$output_csv, "\n")

# ======================== Build hierarchical network ========================

# 4) Hierarchical network nodes: TopCore / SmallCore / GO term

# TopCore nodes
top_core <- data.frame(
  name = c("RNA_core", "Protein_core", "Common_core"),
  type = "TopCore",
  Count = NA,
  x = c(-300, 0, 300),
  y = 0,
  stringsAsFactors = FALSE
)

# SmallCore nodes (3 TopCore × 3 ontologies = 9)
set.seed(123)
small_core <- expand.grid(
  Top      = top_core$name,
  Ontology = c("BP", "MF", "CC"),
  stringsAsFactors = FALSE
) %>%
  rowwise() %>%
  mutate(
    name  = paste(Top, Ontology, sep = "_"),
    type  = "SmallCore",
    Count = NA,
    x     = top_core$x[top_core$name == Top] + sample(c(-50, 0, 50), 1),
    y     = top_core$y[top_core$name == Top] + sample(c(-50, 0, 50), 1)
  ) %>%
  dplyr::select(name, type, Count, x, y, Ontology, Top)

# GO term nodes
go_nodes <- go_combined %>%
  dplyr::mutate(
    name      = Description,
    type      = "GO Term",
    TopCore   = dplyr::case_when(
      SourceType == "RNA"     ~ "RNA_core",
      SourceType == "Protein" ~ "Protein_core",
      SourceType == "Common"  ~ "Common_core"
    ),
    SmallCore = paste(TopCore, ONTOLOGY, sep = "_")
  ) %>%
  dplyr::select(name, type, Count, TopCore, SmallCore, ONTOLOGY)

# Assign coordinates to GO term nodes
go_nodes <- go_nodes %>%
  rowwise() %>%
  mutate(
    idx = match(SmallCore, small_core$name),
    x   = ifelse(!is.na(idx),
                 small_core$x[idx] + runif(1, -30, 30),
                 runif(1, -100, 100)),
    y   = ifelse(!is.na(idx),
                 small_core$y[idx] + runif(1, -30, 30),
                 runif(1, -100, 100))
  ) %>%
  dplyr::select(-idx)

# 5) Combine all nodes and set colors/sizes
nodes_vis_go <- bind_rows(
  top_core,
  small_core %>% dplyr::select(name, type, Count, x, y),
  go_nodes   %>% dplyr::select(name, type, Count, x, y)
) %>%
  dplyr::mutate(
    id    = name,
    label = name,
    title = paste0(name, "<br>Count: ", Count),
    size = dplyr::case_when(
      type == "TopCore"   ~ 25,
      type == "SmallCore" ~ 15,
      type == "GO Term"   ~ ifelse(is.na(Count), 10, log2(Count + 1) * 5),
      TRUE                ~ 10
    )
  )

# 1) Set colors for TopCore / SmallCore first
nodes_vis_go <- nodes_vis_go %>%
  dplyr::mutate(
    color = dplyr::case_when(
      # TopCore colors
      type == "TopCore" & name == "RNA_core"     ~ args$rna_core_color,
      type == "TopCore" & name == "Protein_core" ~ args$protein_core_color,
      type == "TopCore" & name == "Common_core"  ~ args$common_core_color,
      # SmallCore colors (by ontology)
      type == "SmallCore" & grepl("_BP$", name)  ~ args$BP_fill_color,
      type == "SmallCore" & grepl("_CC$", name)  ~ args$CC_fill_color,
      type == "SmallCore" & grepl("_MF$", name)  ~ args$MF_fill_color,
      TRUE                                       ~ NA_character_
    )
  )

# 2) For GO term nodes, map Count to a blue gradient
go_term_nodes <- nodes_vis_go %>%
  dplyr::filter(type == "GO Term") %>%
  dplyr::select(name, type, Count)

if (nrow(go_term_nodes) > 0) {
  go_term_colored <- map_node_color_by_count(
    nodes_df     = go_term_nodes,
    source_color = "#F5DEB3",
    na_color     = "#bdbdbd"
  ) %>%
    dplyr::select(name, color_byCount = color)
  
  # Write GO term colors back into the node table
  nodes_vis_go <- nodes_vis_go %>%
    dplyr::left_join(go_term_colored, by = "name") %>%
    dplyr::mutate(
      color = dplyr::if_else(
        type == "GO Term" & !is.na(color_byCount),
        color_byCount,
        color
      )
    ) %>%
    dplyr::select(-color_byCount)
} else {
  # If there are no GO terms, ensure color is not NA
  nodes_vis_go <- nodes_vis_go %>%
    dplyr::mutate(
      color = dplyr::coalesce(color, "grey70")
    )
}

# Add borders
nodes_vis_go <- nodes_vis_go %>%
  dplyr::mutate(
    borderWidth = if (args$is_show_border) args$border_size else 0,
    color.border = args$border_color,
    color.background = color
  )

# 6) Build edges
edges_go <- bind_rows(
  # TopCore → GO term (direct links)
  go_combined %>%
    dplyr::mutate(
      name = Description,
      from = dplyr::case_when(
        SourceType == "RNA"     ~ "RNA_core",
        SourceType == "Protein" ~ "Protein_core",
        SourceType == "Common"  ~ "Common_core"
      ),
      to = name
    ) %>%
    dplyr::select(from, to),
  # TopCore → SmallCore
  small_core %>%
    dplyr::mutate(from = Top, to = name) %>%
    dplyr::select(from, to),
  # SmallCore → GO Term
  go_nodes %>%
    dplyr::mutate(from = SmallCore, to = name) %>%
    dplyr::select(from, to)
) %>%
  distinct()

cat("  Total nodes:", nrow(nodes_vis_go), "\n")
cat("  Total edges:", nrow(edges_go), "\n")

# 7) Render visNetwork
go_network <- visNetwork(nodes_vis_go, edges_go, main = args$main_title,
                         width = paste0(args$width, "px"),
                         height = paste0(args$height, "px")) %>%
  visNodes(
    shape = "dot",
    font  = list(face = "arial", size = args$axis_text_size)
  ) %>%
  visEdges(color = list(color = "black", highlight = "red")) %>%
  visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
  visLayout(randomSeed = 123, improvedLayout = TRUE) %>%
  visPhysics(stabilization = TRUE, solver = "forceAtlas2Based")

# Add legend
if (args$is_show_legend) {
  legend_nodes <- data.frame(
    label = c("RNA_core", "Protein_core", "Common_core", "BP", "CC", "MF", "GO Term"),
    shape = c(rep("dot", 7)),
    color = c(args$rna_core_color, args$protein_core_color, args$common_core_color,
              args$BP_fill_color, args$CC_fill_color, args$MF_fill_color, "#3182bd"),
    font.size = args$legend_text_size,
    stringsAsFactors = FALSE
  )
  go_network <- go_network %>%
    visLegend(
      addNodes = legend_nodes,
      useGroups = FALSE,
      position = args$legend_position,
      main = list(text = "Legend", style = paste0("font-size:", args$legend_title_size, "px;"))
    )
}

# Save network
visSave(go_network, file = args$output_html)
cat("  Network output file:", args$output_html, "\n")

# Print summary statistics
result <- list(
  go_term_count   = nrow(go_combined),
  node_count      = nrow(nodes_vis_go),
  edge_count      = nrow(edges_go),
  common_count    = sum(go_combined$SourceType == "Common"),
  rna_only        = sum(go_combined$SourceType == "RNA"),
  protein_only    = sum(go_combined$SourceType == "Protein"),
  bp_count        = sum(go_combined$ONTOLOGY == "BP"),
  cc_count        = sum(go_combined$ONTOLOGY == "CC"),
  mf_count        = sum(go_combined$ONTOLOGY == "MF")
)

cat(toJSON(result, auto_unbox = TRUE), "\n")
