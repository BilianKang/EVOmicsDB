#!/usr/bin/env Rscript

# ============================================================
# regulatory_network.r
# miRNA regulatory network (miRNA → mRNA / Protein)
# Supported combinations: miRNA+mRNA, miRNA+Protein
# ============================================================

library(dplyr)
library(scales)
library(visNetwork)
library(multiMiR)
library(jsonlite)
library(argparse)

parser <- ArgumentParser(description = "Build miRNA regulatory network (miRNA -> mRNA/Protein)")
parser$add_argument("--mirna_dataset", type = "character", required = TRUE, help = "Path to miRNA dataset file")
parser$add_argument("--target_dataset", type = "character", required = TRUE, help = "Path to target dataset file (mRNA/Protein)")
parser$add_argument("--target_group", type = "character", default = "mRNA", help = "Target type: mRNA or Protein")
parser$add_argument("--max_targets_per_mirna", type = "integer", default = 15, help = "Max targets per miRNA")
parser$add_argument("--output_html", type = "character", required = TRUE, help = "Output HTML file path")
parser$add_argument("--output_csv", type = "character", required = TRUE, help = "Output CSV file path")
# miRNA p-value parameters
parser$add_argument("--mirna_is_use_padj", type = "logical", default = TRUE, help = "Whether to use adjusted p-value for miRNA")
parser$add_argument("--mirna_pvalue", type = "double", default = 0.05, help = "P-value threshold for miRNA")
# Target p-value parameters
parser$add_argument("--target_is_use_padj", type = "logical", default = TRUE, help = "Whether to use adjusted p-value for target")
parser$add_argument("--target_pvalue", type = "double", default = 0.05, help = "P-value threshold for target")
# Node shape parameters (visNetwork shapes: dot, square, triangle, triangleDown, diamond, star, ellipse, box, circle, database)
parser$add_argument("--mirna_shape", type = "character", default = "diamond", help = "miRNA node shape")
parser$add_argument("--target_shape", type = "character", default = "dot", help = "Target node shape")
# logFC color mapping parameters
parser$add_argument("--low_color", type = "character", default = "#1f78b4", help = "Color for low logFC (downregulated)")
parser$add_argument("--mid_color", type = "character", default = "white", help = "Color for zero logFC")
parser$add_argument("--high_color", type = "character", default = "#e31a1c", help = "Color for high logFC (upregulated)")
args <- parser$parse_args()

# ======================== Helper functions ========================

get_significant <- function(df, pvalue_threshold = 0.05, is_use_padj = TRUE) {
  # Use adj.P.Val or P.Value depending on is_use_padj
  if (is_use_padj && "adj.P.Val" %in% colnames(df)) {
    df %>% dplyr::filter(adj.P.Val < pvalue_threshold)
  } else {
    df %>% dplyr::filter(P.Value < pvalue_threshold)
  }
}

get_mirna_targets <- function(mirna_list, gene_list = NULL, limit = 10000) {
  mirna_ids <- mirna_list$ID
  target_ids <- if (!is.null(gene_list)) gene_list$ID else NULL
  
  results <- get_multimir(
    mirna   = mirna_ids,
    target  = target_ids,
    table   = "all",
    summary = TRUE,
    limit   = limit
  )
  return(results)
}

extract_mirna_targets_summary <- function(mirna_targets) {
  if (nrow(mirna_targets@summary) > 0) {
    associations <- mirna_targets@summary[, c("mature_mirna_id", "target_entrez", "target_symbol")]
    associations$type     <- "predicted"
    associations$database <- "multiple"
    return(associations)
  } else {
    stop("No miRNA-target associations found in summary data")
  }
}

filter_mirna_associations_for_network <- function(
    associations,
    mirna_sig,
    target_sig,
    max_targets_per_miRNA = 30
) {
  mirna_ids  <- unique(mirna_sig$ID)
  target_ids <- unique(target_sig$ID)
  
  df <- associations %>%
    dplyr::filter(
      mature_mirna_id %in% mirna_ids,
      target_symbol   %in% target_ids
    )
  
  if (nrow(df) == 0) return(df)
  
  df <- df %>%
    dplyr::group_by(mature_mirna_id) %>%
    dplyr::slice_head(n = max_targets_per_miRNA) %>%
    dplyr::ungroup()
  
  return(df)
}

# ======================== RDA loading function ========================

read_deg_from_rda <- function(rda_file) {
  env <- new.env()
  load(rda_file, envir = env)
  if (!exists("deg", envir = env)) {
    stop(paste("deg object not found in", rda_file))
  }
  df <- env$deg
  df$ID <- rownames(df)
  return(df)
}

# ======================== Main workflow ========================

cat("Building regulatory network: miRNA ->", args$target_group, "\n")

# Load data (from an RDA file)
mirna_df <- read_deg_from_rda(args$mirna_dataset)
target_df <- read_deg_from_rda(args$target_dataset)

# Filter significant features
mirna_sig <- get_significant(mirna_df, args$mirna_pvalue, args$mirna_is_use_padj)
target_sig <- get_significant(target_df, args$target_pvalue, args$target_is_use_padj)

cat("  Significant miRNAs:", nrow(mirna_sig), "\n")
cat("  Significant targets:", nrow(target_sig), "\n")

if (nrow(mirna_sig) == 0 || nrow(target_sig) == 0) {
  stop("No significant data after filtering")
}

# multiMiR prediction
cat("  Using multiMiR to predict targets...\n")
mirna_targets <- get_mirna_targets(mirna_sig, target_sig, limit = 10000)
mirna_associations_all <- extract_mirna_targets_summary(mirna_targets)

# Filtering
mirna_associations <- filter_mirna_associations_for_network(
  associations           = mirna_associations_all,
  mirna_sig              = mirna_sig,
  target_sig             = target_sig,
  max_targets_per_miRNA  = args$max_targets_per_mirna
)

if (nrow(mirna_associations) == 0) {
  stop("No miRNA-target associations after filtering")
}

cat("  Filtered associations:", nrow(mirna_associations), "\n")

# Color mapping (based on logFC)
range_all <- range(c(mirna_sig$logFC, target_sig$logFC), na.rm = TRUE)

col_fun <- scales::col_numeric(
  palette = c(args$low_color, args$mid_color, args$high_color),
  domain  = range_all
)

# miRNA nodes
mirna_nodes_all <- mirna_sig %>%
  dplyr::select(ID, logFC) %>%
  dplyr::mutate(
    id    = ID,
    label = ID,
    group = "miRNA",
    color = col_fun(logFC),
    title = paste0("miRNA: ", ID, "<br>logFC: ", round(logFC, 3)),
    value = abs(logFC) * 5
  )

# Target nodes
target_nodes_all <- target_sig %>%
  dplyr::select(ID, logFC) %>%
  dplyr::mutate(
    id    = ID,
    label = ID,
    group = args$target_group,
    color = col_fun(logFC),
    title = paste0(args$target_group, ": ", ID, "<br>logFC: ", round(logFC, 3)),
    value = abs(logFC) * 5
  )

# Build edges
edges <- mirna_associations %>%
  dplyr::mutate(
    from   = mature_mirna_id,
    to     = target_symbol,
    color  = "#808080",
    width  = 2,
    title  = paste0(mature_mirna_id, " -> ", target_symbol),
    arrows = "to"
  ) %>%
  dplyr::select(from, to, color, width, title, arrows)

# Remove isolated nodes
used_ids <- unique(c(edges$from, edges$to))
mirna_nodes  <- mirna_nodes_all  %>% dplyr::filter(id %in% used_ids)
target_nodes <- target_nodes_all %>% dplyr::filter(id %in% used_ids)

all_nodes <- dplyr::bind_rows(mirna_nodes, target_nodes) %>%
  dplyr::distinct(id, .keep_all = TRUE)

if (nrow(all_nodes) == 0) {
  stop("All nodes are isolated, cannot build network")
}

cat("  Nodes:", nrow(all_nodes), ", Edges:", nrow(edges), "\n")

# Build network visualization
network <- visNetwork(all_nodes, edges) %>%
  visNodes(
    shape = "dot",
    font  = list(size = 14, face = "arial")
  ) %>%
  visEdges(smooth = list(enabled = TRUE, type = "dynamic")) %>%
  visGroups(groupname = "miRNA", shape = args$mirna_shape, size = 25) %>%
  visGroups(groupname = args$target_group, shape = args$target_shape, size = 20) %>%
  visLegend() %>%
  visOptions(
    highlightNearest = list(enabled = TRUE, degree = 1, hover = TRUE),
    nodesIdSelection = TRUE,
    selectedBy       = "group"
  ) %>%
  visLayout(randomSeed = 123) %>%
  visPhysics(stabilization = TRUE)

# Save outputs
visSave(network, file = args$output_html)
write.table(
  mirna_associations,
  file      = args$output_csv,
  sep       = "\t",
  quote     = FALSE,
  row.names = FALSE
)

cat("  Output HTML:", args$output_html, "\n")
cat("  Output CSV:", args$output_csv, "\n")

# Print summary statistics
result <- list(
  mirna_count = nrow(mirna_nodes),
  target_count = nrow(target_nodes),
  edge_count = nrow(edges)
)

cat(toJSON(result, auto_unbox = TRUE), "\n")
