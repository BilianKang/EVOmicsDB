#!/usr/bin/env Rscript

# ============================================================
# kegg_network.r
# KEGG joint network
# Supported combinations: mRNA+Protein, mRNA+Metabolite, Protein+Metabolite,
#          miRNA+Metabolite, lncRNA+Metabolite
# Internally selects the corresponding logic based on type1/type2
# ============================================================

library(clusterProfiler)
library(dplyr)
library(scales)
library(visNetwork)
library(KEGGREST)
library(org.Hs.eg.db)
library(stringr)
library(multiMiR)
library(jsonlite)
library(argparse)

# --- Get script path for loading database ---
get_script_path <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  file_arg <- "--file="
  script_path <- sub(file_arg, "", args[grep(file_arg, args)])
  return(normalizePath(script_path))
}

parser <- ArgumentParser(description = "Build KEGG joint network for multi-omics data")
parser$add_argument("--dataset1", type = "character", required = TRUE, help = "Path to dataset1 file")
parser$add_argument("--dataset2", type = "character", required = TRUE, help = "Path to dataset2 file")
parser$add_argument("--type1", type = "character", required = TRUE, help = "Type of dataset1: mRNA/miRNA/Protein/Metabolite/lncRNA")
parser$add_argument("--type2", type = "character", required = TRUE, help = "Type of dataset2: mRNA/miRNA/Protein/Metabolite/lncRNA")
parser$add_argument("--pvalue_threshold", type = "double", default = 0.05, help = "P-value cutoff")
parser$add_argument("--p_adjust_method", type = "character", default = "BH", help = "P-value adjustment method")
parser$add_argument("--organism", type = "character", default = "hsa", help = "Organism code")
parser$add_argument("--max_targets_per_mirna", type = "integer", default = 15, help = "Max targets per miRNA (for miRNA+Metabolite)")
parser$add_argument("--output_html", type = "character", required = TRUE, help = "Output HTML file path")
parser$add_argument("--output_csv", type = "character", required = TRUE, help = "Output CSV file path")
# Titles
parser$add_argument("--main_title", type = "character", default = "KEGG Joint Network", help = "Main title")
parser$add_argument("--main_title_size", type = "integer", default = 14, help = "Main title font size")
parser$add_argument("--axis_text_size", type = "integer", default = 10, help = "Node label font size")
# Dot
parser$add_argument("--fill_colors", type = "character", default = "#F5DEB3,#9ecae1,#3182bd", help = "Fill colors (Source,Low,High)")
parser$add_argument("--border_color", type = "character", default = "black", help = "Border color")
parser$add_argument("--border_size", type = "double", default = 1.0, help = "Border size")
# Legend
parser$add_argument("--is_show_legend", type = "character", default = "TRUE", help = "Show legend (TRUE/FALSE)")
parser$add_argument("--legend_title_size", type = "integer", default = 10, help = "Legend title font size")
parser$add_argument("--legend_text_size", type = "integer", default = 9, help = "Legend label font size")
parser$add_argument("--legend_position", type = "character", default = "right", help = "Legend position")
# Export settings
parser$add_argument("--is_show_border", type = "character", default = "TRUE", help = "Show border (TRUE/FALSE)")
parser$add_argument("--width", type = "integer", default = 1200, help = "Output width (px)")
parser$add_argument("--height", type = "integer", default = 800, help = "Output height (px)")
args <- parser$parse_args()

# Parse boolean arguments
args$is_show_legend <- toupper(args$is_show_legend) == "TRUE"
args$is_show_border <- toupper(args$is_show_border) == "TRUE"

# Parse fill colors
fill_colors_vec <- strsplit(args$fill_colors, ",")[[1]]
if (length(fill_colors_vec) < 3) {
  fill_colors_vec <- c("#F5DEB3", "#9ecae1", "#3182bd")
}

# ======================== Helper functions ========================

get_significant <- function(df, pvalue_threshold = 0.05) {
  df %>% dplyr::filter(P.Value < pvalue_threshold)
}

query_kegg_compounds <- function(metabolite_names) {
  kegg_ids <- c()
  kegg_mapping <- data.frame(
    Metabolite = character(),
    KEGG_ID = character(),
    Description = character(),
    stringsAsFactors = FALSE
  )
  
  if (length(metabolite_names) == 0) {
    message("  [KEGG] No significant metabolites for query.")
    return(list(kegg_ids = character(), mapping = kegg_mapping))
  }
  
  for (metabolite in metabolite_names) {
    simple_name <- str_replace_all(metabolite, "[^[:alnum:]]", " ")
    simple_name <- str_squish(simple_name)
    
    result <- tryCatch({
      keggFind("compound", simple_name)
    }, error = function(e) {
      message("  [KEGG] Query failed for: ", metabolite)
      return(NULL)
    })
    
    if (is.null(result) || length(result) == 0) next
    
    kegg_id <- names(result)[1]
    description <- result[1]
    
    kegg_ids <- c(kegg_ids, kegg_id)
    kegg_mapping <- rbind(kegg_mapping, data.frame(
      Metabolite = metabolite,
      KEGG_ID = kegg_id,
      Description = description,
      stringsAsFactors = FALSE
    ))
    
    Sys.sleep(0.5)
  }
  
  return(list(kegg_ids = unique(kegg_ids), mapping = kegg_mapping))
}

get_kegg_ids_for_group <- function(metabolite_names, mapping_df) {
  mapped <- mapping_df %>%
    dplyr::filter(Metabolite %in% metabolite_names) %>%
    dplyr::pull(KEGG_ID)
  return(unique(mapped))
}

get_mirna_targets <- function(mirna_list, gene_list = NULL, limit = 10000) {
  mirna_ids <- mirna_list$ID
  target_ids <- if (!is.null(gene_list)) gene_list$ID else NULL

  results <- get_multimir(
    mirna   = mirna_ids,
    target  = target_ids,
    table   = "all",
    summary = TRUE,
    limit   = limit
  )
  return(results)
}

extract_mirna_targets_summary <- function(mirna_targets) {
  if (nrow(mirna_targets@summary) > 0) {
    associations <- mirna_targets@summary[, c("mature_mirna_id", "target_entrez", "target_symbol")]
    associations$type     <- "predicted"
    associations$database <- "multiple"
    return(associations)
  } else {
    stop("No miRNA-target associations found in summary data")
  }
}

########################### Standardized KEGG (compareCluster) post-processing ###########################
## This function implements the exact standardized pipeline:
## as.data.frame -> empty check -> geneID->GeneID -> parse GeneRatio -> group_by Description merge -> write.table
standardize_kegg_comparecluster_result <- function(
    cpd_enrich_result,
    out_prefix = NULL,
    source_label = "Metabolite"
) {
  metab_kegg_df <- as.data.frame(cpd_enrich_result)

  if (nrow(metab_kegg_df) == 0) {
    message("    [KEGG] KEGG enrichment result is empty. Skipping network.")
    return(NULL)
  }

  ## Unify geneID column name (common output is geneID)
  if ("geneID" %in% colnames(metab_kegg_df) && !"GeneID" %in% colnames(metab_kegg_df)) {
    metab_kegg_df <- dplyr::rename(metab_kegg_df, GeneID = geneID)
  }

  metab_kegg_df$Source <- source_label

  ## Parse GeneRatio: "x/y" -> numeric
  parse_gene_ratio <- function(x) {
    s <- strsplit(as.character(x), "/")
    vapply(s, function(z) {
      if (length(z) != 2) return(NA_real_)
      as.numeric(z[1]) / as.numeric(z[2])
    }, numeric(1))
  }

  metab_kegg_df <- metab_kegg_df %>%
    dplyr::mutate(GeneRatioNum = parse_gene_ratio(GeneRatio))

  ## Merge by Description (pathway name) to ensure uniqueness
  metab_kegg_df_combined <- metab_kegg_df %>%
    dplyr::group_by(Description) %>%
    dplyr::summarise(
      ID        = dplyr::first(ID),
      GeneRatio = sum(GeneRatioNum, na.rm = TRUE),
      Count     = sum(Count,        na.rm = TRUE),
      GeneID    = paste(unique(GeneID), collapse = "; "),
      pvalue    = min(pvalue,  na.rm = TRUE),
      p.adjust  = min(p.adjust,na.rm = TRUE),
      qvalue    = min(qvalue,  na.rm = TRUE),
      Source    = source_label,
      .groups   = "drop"
    )

  ## Optionally write output file
  if (!is.null(out_prefix)) {
    write.table(
      metab_kegg_df_combined,
      file      = paste0(out_prefix, "_", source_label, "_KEGG.txt"),
      sep       = "\t",
      row.names = FALSE,
      quote     = FALSE
    )
  }

  return(metab_kegg_df_combined)
}

map_node_color_by_count <- function(nodes_df,
                                    source_color = "#F5DEB3",
                                    na_color     = "#bdbdbd",
                                    palette_cols = c("#deebf7", "#9ecae1", "#3182bd"),
                                    border_color = "black",
                                    border_size  = 1.0) {
  count_range <- range(nodes_df$Count, na.rm = TRUE)
  if (diff(count_range) == 0) {
    count_range <- c(count_range[1] - 1e-6, count_range[2] + 1e-6)
  }
  
  col_fun <- scales::col_numeric(
    palette = palette_cols,
    domain  = count_range
  )
  
  nodes_df %>%
    dplyr::mutate(
      color = dplyr::case_when(
        type == "Source"  ~ source_color,
        is.na(Count)      ~ na_color,
        TRUE              ~ col_fun(Count)
      ),
      color.border = border_color,
      borderWidth  = border_size
    )
}

# ======================== Build KEGG networks for each combination ========================

build_kegg_mrna_protein <- function(mrna_sig, protein_sig, pvalue_threshold, p_adjust_method, organism) {
  cat("  [KEGG] mRNA + Protein enrichment network...\n")

  rna_genes  <- mrna_sig$ID
  rna_entrez <- bitr(rna_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  if (nrow(rna_entrez) == 0) stop("mRNA cannot be mapped to ENTREZID")

  rna_kegg <- enrichKEGG(
    gene          = rna_entrez$ENTREZID,
    organism      = organism,
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )
  rna_kegg_df <- as.data.frame(rna_kegg)
  if (nrow(rna_kegg_df) == 0) stop("mRNA KEGG enrichment empty")
  rna_kegg_df$Source <- "RNA"

  protein_genes  <- protein_sig$ID
  protein_entrez <- bitr(protein_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  if (nrow(protein_entrez) == 0) stop("Protein cannot be mapped to ENTREZID")

  protein_kegg <- enrichKEGG(
    gene          = protein_entrez$ENTREZID,
    organism      = organism,
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )
  protein_kegg_df <- as.data.frame(protein_kegg)
  if (nrow(protein_kegg_df) == 0) stop("Protein KEGG enrichment empty")
  protein_kegg_df$Source <- "Protein"
  
  combined <- full_join(
    rna_kegg_df     %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    protein_kegg_df %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    by = c("ID", "Description"),
    suffix = c("_RNA", "_Protein")
  ) %>%
    mutate(
      SourceType = case_when(
        !is.na(Count_RNA) & !is.na(Count_Protein) ~ "Common",
        !is.na(Count_RNA) &  is.na(Count_Protein) ~ "RNA",
        is.na(Count_RNA)  & !is.na(Count_Protein) ~ "Protein"
      ),
      Count = ifelse(SourceType == "Common", Count_RNA + Count_Protein,
                     ifelse(!is.na(Count_RNA), Count_RNA, Count_Protein)),
      p.adjust = ifelse(SourceType == "Common", pmin(p.adjust_RNA, p.adjust_Protein),
                        ifelse(!is.na(p.adjust_RNA), p.adjust_RNA, p.adjust_Protein))
    )
  
  return(combined)
}

build_kegg_gene_metabolite <- function(gene_sig, metabolite_df, gene_type, pvalue_threshold, p_adjust_method, organism) {
  cat("  [KEGG]", gene_type, "+ Metabolite enrichment network...\n")

  genes <- gene_sig$ID
  gene_entrez <- bitr(genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  if (nrow(gene_entrez) == 0) stop(paste(gene_type, "cannot be mapped to ENTREZID"))

  gene_kegg <- enrichKEGG(
    gene          = gene_entrez$ENTREZID,
    organism      = organism,
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )
  gene_kegg_df <- as.data.frame(gene_kegg)
  if (nrow(gene_kegg_df) == 0) stop(paste(gene_type, "KEGG enrichment empty"))
  gene_kegg_df$Source <- gene_type

  diff_metabolites <- metabolite_df %>% dplyr::filter(P.Value < pvalue_threshold) %>% dplyr::pull(ID)
  up_metabolites   <- metabolite_df %>% dplyr::filter(logFC > 0) %>% dplyr::pull(ID)
  down_metabolites <- metabolite_df %>% dplyr::filter(logFC < 0) %>% dplyr::pull(ID)
  
  if (length(diff_metabolites) == 0) stop("No significant metabolites")
  
  kegg_results <- query_kegg_compounds(diff_metabolites)
  if (nrow(kegg_results$mapping) == 0) stop("Metabolites not mapped to KEGG ID")
  
  up_kegg   <- get_kegg_ids_for_group(up_metabolites, kegg_results$mapping)
  down_kegg <- get_kegg_ids_for_group(down_metabolites, kegg_results$mapping)
  
  de_cpd <- list(Upregulated = up_kegg, Downregulated = down_kegg)
  de_cpd_cleaned <- lapply(de_cpd, function(x) gsub("cpd:", "", x))
  
  if (all(sapply(de_cpd_cleaned, length) == 0)) stop("No KEGG IDs for metabolites")
  
  cpd_enrich_result <- compareCluster(
    geneClusters  = de_cpd_cleaned,
    fun           = "enrichKEGG",
    organism      = "cpd",
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )

  ## Use standardized post-processing to ensure pathway uniqueness
  metab_kegg_df_combined <- standardize_kegg_comparecluster_result(
    cpd_enrich_result = cpd_enrich_result,
    out_prefix        = NULL,
    source_label      = "Metabolite"
  )

  if (is.null(metab_kegg_df_combined)) {
    stop("Metabolite KEGG enrichment empty after standardization")
  }

  combined <- full_join(
    gene_kegg_df           %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    metab_kegg_df_combined %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    by = c("ID", "Description"),
    suffix = c("_Gene", "_Metab")
  ) %>%
    mutate(
      SourceType = case_when(
        !is.na(Count_Gene) & !is.na(Count_Metab) ~ "Common",
        !is.na(Count_Gene) &  is.na(Count_Metab) ~ gene_type,
        is.na(Count_Gene)  & !is.na(Count_Metab) ~ "Metabolite"
      ),
      Count = ifelse(SourceType == "Common", Count_Gene + Count_Metab,
                     ifelse(!is.na(Count_Gene), Count_Gene, Count_Metab)),
      p.adjust = ifelse(SourceType == "Common", pmin(p.adjust_Gene, p.adjust_Metab),
                        ifelse(!is.na(p.adjust_Gene), p.adjust_Gene, p.adjust_Metab))
    )

  return(combined)
}

build_kegg_mirna_metabolite <- function(mirna_sig, metabolite_df, pvalue_threshold, p_adjust_method, organism, max_targets_per_mirna) {
  cat("  [KEGG] miRNA + Metabolite pathway network...\n")
  
  cat("    Using multiMiR to get miRNA targets...\n")
  mirna_targets <- get_multimir(
    mirna   = mirna_sig$ID,
    target  = NULL,
    table   = "all",
    summary = TRUE,
    limit   = 10000
  )
  
  mirna_associations <- mirna_targets@summary %>%
    dplyr::filter(mature_mirna_id %in% mirna_sig$ID) %>%
    dplyr::group_by(mature_mirna_id) %>%
    dplyr::slice_head(n = max_targets_per_mirna) %>%
    dplyr::ungroup()
  
  if (nrow(mirna_associations) == 0) stop("miRNA targets empty")
  
  target_genes <- unique(mirna_associations$target_symbol)
  target_genes <- target_genes[!is.na(target_genes) & target_genes != ""]
  
  if (length(target_genes) == 0) stop("miRNA target gene list empty")
  
  mirna_entrez <- bitr(target_genes, fromType = "SYMBOL", toType = "ENTREZID", OrgDb = org.Hs.eg.db)
  if (nrow(mirna_entrez) == 0) stop("miRNA targets cannot be mapped to ENTREZID")
  
  mirna_kegg <- enrichKEGG(
    gene          = mirna_entrez$ENTREZID,
    organism      = organism,
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )
  mirna_kegg_df <- as.data.frame(mirna_kegg)
  if (nrow(mirna_kegg_df) == 0) stop("miRNA target KEGG enrichment empty")
  mirna_kegg_df$Source <- "miRNA_target"

  diff_metabolites <- metabolite_df %>% dplyr::filter(P.Value < pvalue_threshold) %>% dplyr::pull(ID)
  up_metabolites   <- metabolite_df %>% dplyr::filter(logFC > 0) %>% dplyr::pull(ID)
  down_metabolites <- metabolite_df %>% dplyr::filter(logFC < 0) %>% dplyr::pull(ID)
  
  if (length(diff_metabolites) == 0) stop("No significant metabolites")
  
  kegg_results <- query_kegg_compounds(diff_metabolites)
  if (nrow(kegg_results$mapping) == 0) stop("Metabolites not mapped to KEGG ID")
  
  up_kegg   <- get_kegg_ids_for_group(up_metabolites, kegg_results$mapping)
  down_kegg <- get_kegg_ids_for_group(down_metabolites, kegg_results$mapping)
  
  de_cpd <- list(Upregulated = up_kegg, Downregulated = down_kegg)
  de_cpd_cleaned <- lapply(de_cpd, function(x) gsub("cpd:", "", x))
  
  if (all(sapply(de_cpd_cleaned, length) == 0)) stop("No KEGG IDs for metabolites")
  
  cpd_enrich_result <- compareCluster(
    geneClusters  = de_cpd_cleaned,
    fun           = "enrichKEGG",
    organism      = "cpd",
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )

  ## Use standardized post-processing to ensure pathway uniqueness
  metab_kegg_df_combined <- standardize_kegg_comparecluster_result(
    cpd_enrich_result = cpd_enrich_result,
    out_prefix        = NULL,
    source_label      = "Metabolite"
  )

  if (is.null(metab_kegg_df_combined)) {
    stop("Metabolite KEGG enrichment empty after standardization")
  }

  combined <- full_join(
    mirna_kegg_df          %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    metab_kegg_df_combined %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    by = c("ID", "Description"),
    suffix = c("_miRNA", "_Metab")
  ) %>%
    mutate(
      SourceType = case_when(
        !is.na(Count_miRNA) & !is.na(Count_Metab) ~ "Common",
        !is.na(Count_miRNA) &  is.na(Count_Metab) ~ "miRNA_target",
        is.na(Count_miRNA)  & !is.na(Count_Metab) ~ "Metabolite"
      ),
      Count = ifelse(SourceType == "Common", Count_miRNA + Count_Metab,
                     ifelse(!is.na(Count_miRNA), Count_miRNA, Count_Metab)),
      p.adjust = ifelse(SourceType == "Common", pmin(p.adjust_miRNA, p.adjust_Metab),
                        ifelse(!is.na(p.adjust_miRNA), p.adjust_miRNA, p.adjust_Metab))
    )
  
  return(combined)
}

########### lncRNA + Metabolite: lnc-target miRNA + lnc-target genes -> UNION genes KEGG + Metabolite KEGG ###########
build_kegg_lnc_metabolite <- function(lnc_sig, metabolite_df, master_lnc_targets,
                                       pvalue_threshold, p_adjust_method, organism,
                                       max_targets_per_mirna = 15) {
  cat("  [KEGG] lncRNA + Metabolite: lnc-target miRNA & lnc-target genes -> UNION genes KEGG + metabolite KEGG network...\n")

  if (!all(c("ID", "logFC", "P.Value") %in% colnames(metabolite_df))) {
    stop("metabolite_df must contain columns: ID, logFC, P.Value")
  }

  if ("lncRNA" %in% colnames(lnc_sig)) {
    lnc_id_col <- "lncRNA"
  } else if ("ID" %in% colnames(lnc_sig)) {
    lnc_id_col <- "ID"
  } else {
    stop("lnc_sig must contain column 'lncRNA' or 'ID'.")
  }

  lnc_list <- unique(lnc_sig[[lnc_id_col]])
  lnc_list <- lnc_list[!is.na(lnc_list) & lnc_list != ""]
  if (length(lnc_list) == 0) {
    stop("No differential lncRNAs found.")
  }
  cat("    Differential lncRNA count:", length(lnc_list), "\n")

  lnc_target_df0 <- master_lnc_targets %>%
    dplyr::filter(lncRNA %in% lnc_list) %>%
    dplyr::select(lncRNA, target, target_type) %>%
    dplyr::distinct()

  if (nrow(lnc_target_df0) == 0) {
    stop("No targets found for these lncRNAs in master_lnc_targets.")
  }

  lnc_target_df <- lnc_target_df0 %>%
    dplyr::mutate(
      class = dplyr::case_when(
        stringr::str_detect(target_type, regex("miRNA", ignore_case = TRUE))                ~ "miRNA",
        stringr::str_detect(target_type, regex("protein|pcg|gene|tf", ignore_case = TRUE))  ~ "gene_protein",
        stringr::str_detect(target_type, regex("RNA", ignore_case = TRUE))                  ~ "RNA",
        TRUE                                                                                ~ "Other"
      )
    )

  ## A: lnc direct gene/protein targets
  lnc_gene_targets <- lnc_target_df %>%
    dplyr::filter(class %in% c("gene_protein", "RNA")) %>%
    dplyr::pull(target) %>%
    unique()
  lnc_gene_targets <- lnc_gene_targets[!is.na(lnc_gene_targets) & lnc_gene_targets != ""]

  if (length(lnc_gene_targets) == 0) {
    stop("No gene/protein-like targets found for lncRNAs. Cannot run KEGG.")
  }
  cat("    lnc direct gene targets (A):", length(lnc_gene_targets), "\n")

  ## lnc-target miRNAs (for multiMiR)
  lnc_mirna_targets <- lnc_target_df %>%
    dplyr::filter(class == "miRNA") %>%
    dplyr::pull(target) %>%
    unique()
  lnc_mirna_targets <- lnc_mirna_targets[!is.na(lnc_mirna_targets) & lnc_mirna_targets != ""]

  if (length(lnc_mirna_targets) == 0) {
    stop("No miRNA targets found for lncRNAs. Cannot infer miRNA-mediated genes.")
  }
  cat("    lnc-target miRNAs (for multiMiR):", length(lnc_mirna_targets), "\n")

  ## B: multiMiR inferred gene targets via lnc-target miRNAs
  cat("    Running multiMiR to infer gene targets from lnc-target miRNAs...\n")
  mirna_list_df <- data.frame(ID = lnc_mirna_targets, stringsAsFactors = FALSE)

  mirna_targets_obj <- get_mirna_targets(
    mirna_list = mirna_list_df,
    gene_list  = NULL,
    limit      = 10000
  )
  mirna_associations_all <- extract_mirna_targets_summary(mirna_targets_obj)

  mirna_associations <- mirna_associations_all %>%
    dplyr::group_by(mature_mirna_id) %>%
    dplyr::slice_head(n = max_targets_per_mirna) %>%
    dplyr::ungroup()

  if (nrow(mirna_associations) == 0) {
    stop("multiMiR returned empty miRNA-gene associations after filtering.")
  }

  mirna_gene_targets <- unique(mirna_associations$target_symbol)
  mirna_gene_targets <- mirna_gene_targets[!is.na(mirna_gene_targets) & mirna_gene_targets != ""]

  if (length(mirna_gene_targets) == 0) {
    stop("miRNA-inferred gene target list is empty.")
  }
  cat("    miRNA-inferred gene targets (B):", length(mirna_gene_targets), "\n")

  ## UNION genes (A ∪ B)
  lnc_related_genes <- union(lnc_gene_targets, mirna_gene_targets)
  if (length(lnc_related_genes) == 0) {
    stop("UNION gene set is empty. Cannot construct KEGG network.")
  }
  cat("    UNION lnc-related genes (A ∪ B):", length(lnc_related_genes), "\n")

  ## KEGG enrichment for UNION gene set
  cat("    Running KEGG enrichment for UNION genes...\n")
  lnc_related_gene_entrez <- bitr(
    lnc_related_genes,
    fromType = "SYMBOL",
    toType   = "ENTREZID",
    OrgDb    = org.Hs.eg.db
  )

  if (nrow(lnc_related_gene_entrez) == 0) {
    stop("UNION genes cannot be mapped to ENTREZID.")
  }
  cat("      Mapped UNION genes to ENTREZID:", nrow(lnc_related_gene_entrez), "\n")

  lnc_related_gene_kegg <- enrichKEGG(
    gene          = lnc_related_gene_entrez$ENTREZID,
    organism      = organism,
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )
  lnc_related_gene_kegg_df <- as.data.frame(lnc_related_gene_kegg)

  if (nrow(lnc_related_gene_kegg_df) == 0) {
    stop("UNION gene KEGG enrichment is empty.")
  }
  lnc_related_gene_kegg_df$Source <- "lncRelatedGene"

  ## Metabolite KEGG enrichment (standardized)
  cat("    Running metabolite KEGG enrichment...\n")
  diff_metabolites <- metabolite_df %>% dplyr::filter(P.Value < pvalue_threshold) %>% dplyr::pull(ID)
  up_metabolites   <- metabolite_df %>% dplyr::filter(logFC > 0) %>% dplyr::pull(ID)
  down_metabolites <- metabolite_df %>% dplyr::filter(logFC < 0) %>% dplyr::pull(ID)

  if (length(diff_metabolites) == 0) {
    stop("No significant metabolites detected.")
  }

  kegg_results <- query_kegg_compounds(diff_metabolites)
  if (nrow(kegg_results$mapping) == 0) {
    stop("No metabolites were mapped to KEGG compound IDs.")
  }

  up_kegg   <- get_kegg_ids_for_group(up_metabolites, kegg_results$mapping)
  down_kegg <- get_kegg_ids_for_group(down_metabolites, kegg_results$mapping)

  de_cpd <- list(Upregulated = up_kegg, Downregulated = down_kegg)
  de_cpd_cleaned <- lapply(de_cpd, function(x) gsub("cpd:", "", x))

  if (all(sapply(de_cpd_cleaned, length) == 0)) {
    stop("No KEGG compound IDs available for enrichment.")
  }

  cpd_enrich_result <- compareCluster(
    geneClusters  = de_cpd_cleaned,
    fun           = "enrichKEGG",
    organism      = "cpd",
    pvalueCutoff  = pvalue_threshold,
    pAdjustMethod = p_adjust_method
  )

  metab_kegg_df_combined <- standardize_kegg_comparecluster_result(
    cpd_enrich_result = cpd_enrich_result,
    out_prefix        = NULL,
    source_label      = "Metabolite"
  )
  if (is.null(metab_kegg_df_combined)) {
    stop("Metabolite KEGG enrichment empty after standardization")
  }

  ## Join pathways and build combined result
  cat("    Joining pathways...\n")
  combined <- dplyr::full_join(
    lnc_related_gene_kegg_df %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    metab_kegg_df_combined   %>% dplyr::select(ID, Description, Count, p.adjust, Source),
    by = c("ID", "Description"),
    suffix = c("_Gene", "_Metab")
  ) %>%
    dplyr::mutate(
      SourceType = dplyr::case_when(
        !is.na(Count_Gene)  & !is.na(Count_Metab) ~ "Common",
        !is.na(Count_Gene)  &  is.na(Count_Metab) ~ "lncRelatedGene",
        is.na(Count_Gene)   & !is.na(Count_Metab) ~ "Metabolite"
      ),
      Count = dplyr::case_when(
        SourceType == "Common"         ~ Count_Gene + Count_Metab,
        SourceType == "lncRelatedGene" ~ Count_Gene,
        SourceType == "Metabolite"     ~ Count_Metab
      ),
      p.adjust = dplyr::case_when(
        SourceType == "Common"         ~ pmin(p.adjust_Gene, p.adjust_Metab, na.rm = TRUE),
        SourceType == "lncRelatedGene" ~ p.adjust_Gene,
        SourceType == "Metabolite"     ~ p.adjust_Metab
      )
    )

  combined <- combined[!is.na(combined$SourceType), ]
  if (nrow(combined) == 0) {
    stop("Combined pathway table is empty.")
  }

  return(combined)
}

build_kegg_visnetwork <- function(combined, output_html, output_csv,
                                   main_title = "KEGG Joint Network",
                                   main_title_size = 14,
                                   axis_text_size = 10,
                                   fill_colors = c("#F5DEB3", "#9ecae1", "#3182bd"),
                                   border_color = "black",
                                   border_size = 1.0,
                                   is_show_legend = TRUE,
                                   legend_title_size = 10,
                                   legend_text_size = 9,
                                   legend_position = "right",
                                   is_show_border = TRUE,
                                   width = 1200,
                                   height = 800) {
  if (nrow(combined) == 0) stop("Combined result empty, cannot build network")
  
  # Extract colors
  source_color <- fill_colors[1]
  palette_cols <- c("#deebf7", fill_colors[2], fill_colors[3])
  
  nodes <- data.frame(
    name = unique(c(combined$SourceType, combined$Description)),
    type = c(
      rep("Source",  length(unique(combined$SourceType))),
      rep("Pathway", length(unique(combined$Description)))
    ),
    Count = c(
      rep(NA, length(unique(combined$SourceType))),
      combined$Count[match(unique(combined$Description), combined$Description)]
    ),
    stringsAsFactors = FALSE
  )
  
  nodes_colored <- map_node_color_by_count(
    nodes,
    source_color = source_color,
    palette_cols = palette_cols,
    border_color = border_color,
    border_size  = border_size
  )
  
  nodes_vis <- nodes_colored %>%
    mutate(
      id    = name,
      label = name,
      title = paste0(name, "<br>Count: ", Count),
      size  = ifelse(is.na(Count), 10, log2(Count + 1) * 5)
    )
  
  edges <- combined %>%
    dplyr::select(from = SourceType, to = Description)
  
  # Build edge color based on border settings
  edge_color <- if (is_show_border) border_color else "transparent"
  
  network <- visNetwork(nodes_vis, edges, 
                        main = list(text = main_title, 
                                    style = paste0("font-size:", main_title_size, "px; font-weight:bold;")),
                        width = paste0(width, "px"),
                        height = paste0(height, "px")) %>%
    visNodes(shape = "dot", 
             font = list(face = "arial", size = axis_text_size),
             borderWidth = if (is_show_border) border_size else 0) %>%
    visEdges(color = list(color = edge_color, highlight = "red")) %>%
    visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
    visLayout(randomSeed = 123) %>%
    visPhysics(stabilization = TRUE)
  
  # Add legend if enabled
  if (is_show_legend) {
    legend_nodes <- data.frame(
      label = c("Source", "Low Count", "High Count"),
      color = c(source_color, fill_colors[2], fill_colors[3]),
      shape = "dot",
      font.size = legend_text_size
    )
    network <- network %>%
      visLegend(addNodes = legend_nodes, useGroups = FALSE, position = legend_position,
                main = list(text = "Legend", style = paste0("font-size:", legend_title_size, "px;")))
  }
  
  visSave(network, file = output_html)
  write.table(combined, file = output_csv, sep = "\t", quote = FALSE, row.names = FALSE)
  
  cat("  Output HTML:", output_html, "\n")
  
  return(list(
    pathway_count = length(unique(combined$Description)),
    node_count = nrow(nodes_vis),
    edge_count = nrow(edges)
  ))
}

# ======================== Read RDA function ========================

read_deg_from_rda <- function(rda_file) {
  env <- new.env()
  load(rda_file, envir = env)
  if (!exists("deg", envir = env)) {
    stop(paste("deg object not found in", rda_file))
  }
  df <- env$deg
  df$ID <- rownames(df)
  return(df)
}

# ======================== Main logic ========================

cat("Building KEGG network:", args$type1, "+", args$type2, "\n")

# Load master_lnc_targets database if lncRNA is involved
master_lnc_targets <- NULL
combo_check <- sort(c(args$type1, args$type2))
if ("lncRNA" %in% combo_check) {
  script_dir <- dirname(get_script_path())
  master_lnc_targets_path <- file.path(script_dir, "../../../db/rda/master_lncRNA_target_database.csv")
  if (!file.exists(master_lnc_targets_path)) {
    stop(paste("Master lncRNA targets database not found at:", master_lnc_targets_path))
  }
  master_lnc_targets <- read.csv(master_lnc_targets_path, stringsAsFactors = FALSE)
  cat("  Master lncRNA database loaded:", nrow(master_lnc_targets), "records\n")
}

df1 <- read_deg_from_rda(args$dataset1)
df2 <- read_deg_from_rda(args$dataset2)

sig1 <- get_significant(df1, args$pvalue_threshold)
sig2 <- get_significant(df2, args$pvalue_threshold)

cat("  Significant", args$type1, ":", nrow(sig1), "\n")
cat("  Significant", args$type2, ":", nrow(sig2), "\n")

combo <- sort(c(args$type1, args$type2))
combo_str <- paste(combo, collapse = "_")

combined <- NULL

if (combo_str == "mRNA_Protein") {
  if (args$type1 == "mRNA") {
    combined <- build_kegg_mrna_protein(sig1, sig2, args$pvalue_threshold, args$p_adjust_method, args$organism)
  } else {
    combined <- build_kegg_mrna_protein(sig2, sig1, args$pvalue_threshold, args$p_adjust_method, args$organism)
  }
} else if (combo_str == "Metabolite_mRNA") {
  if (args$type1 == "mRNA") {
    combined <- build_kegg_gene_metabolite(sig1, df2, "RNA", args$pvalue_threshold, args$p_adjust_method, args$organism)
  } else {
    combined <- build_kegg_gene_metabolite(sig2, df1, "RNA", args$pvalue_threshold, args$p_adjust_method, args$organism)
  }
} else if (combo_str == "Metabolite_Protein") {
  if (args$type1 == "Protein") {
    combined <- build_kegg_gene_metabolite(sig1, df2, "Protein", args$pvalue_threshold, args$p_adjust_method, args$organism)
  } else {
    combined <- build_kegg_gene_metabolite(sig2, df1, "Protein", args$pvalue_threshold, args$p_adjust_method, args$organism)
  }
} else if (combo_str == "Metabolite_miRNA") {
  if (args$type1 == "miRNA") {
    combined <- build_kegg_mirna_metabolite(sig1, df2, args$pvalue_threshold, args$p_adjust_method, args$organism, args$max_targets_per_mirna)
  } else {
    combined <- build_kegg_mirna_metabolite(sig2, df1, args$pvalue_threshold, args$p_adjust_method, args$organism, args$max_targets_per_mirna)
  }
} else if (combo_str == "Metabolite_lncRNA") {
  if (args$type1 == "lncRNA") {
    combined <- build_kegg_lnc_metabolite(sig1, df2, master_lnc_targets, args$pvalue_threshold, args$p_adjust_method, args$organism, args$max_targets_per_mirna)
  } else {
    combined <- build_kegg_lnc_metabolite(sig2, df1, master_lnc_targets, args$pvalue_threshold, args$p_adjust_method, args$organism, args$max_targets_per_mirna)
  }
} else {
  stop(paste("Unsupported combination:", args$type1, "+", args$type2))
}

result <- build_kegg_visnetwork(
  combined, 
  args$output_html, 
  args$output_csv,
  main_title = args$main_title,
  main_title_size = args$main_title_size,
  axis_text_size = args$axis_text_size,
  fill_colors = fill_colors_vec,
  border_color = args$border_color,
  border_size = args$border_size,
  is_show_legend = args$is_show_legend,
  legend_title_size = args$legend_title_size,
  legend_text_size = args$legend_text_size,
  legend_position = args$legend_position,
  is_show_border = args$is_show_border,
  width = args$width,
  height = args$height
)
cat(toJSON(result, auto_unbox = TRUE), "\n")
