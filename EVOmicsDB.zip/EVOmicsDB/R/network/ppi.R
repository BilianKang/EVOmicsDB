#!/usr/bin/env Rscript

library(tidyverse)
library(org.Hs.eg.db)
library(clusterProfiler)
library(STRINGdb)
library(igraph)
library(ggraph)
library(argparse)

# --- 1. Define command-line arguments ---
parser <- ArgumentParser(description="Generate a PPI network from miRNA data.")
parser$add_argument("--input_rda", type = "character", required = TRUE, help= "Path to the input RDA file containing DEG results (e.g., DEG.rda).")
parser$add_argument("--output_png", type = "character", required = TRUE, help = "Path to save the PPI network plot (e.g., PPI.png)")
parser$add_argument("--output_csv", type = "character", required = TRUE, help = "Path to save the PPI interactions (e.g., String_interactions.txt)")
parser$add_argument("--output_pdf", type="character", default=NULL, help="Optional path to save the plot as PDF (e.g., plot_name.pdf).")
parser$add_argument("--is_use_padj", type="logical", default=TRUE, help="Whether to use adjusted p-values (default: TRUE).")
parser$add_argument("--log2fc_threshold", type = "numeric", default = 0.585, help = "Log2 fold change threshold for significance (default: 0.585)")
parser$add_argument("--pvalue_threshold", type = "numeric", default = 0.05, help = "P-value threshold for significance (default: 0.05)")
parser$add_argument("--top_n", type="integer", default=10, help="Number of top miRNAs to keep (default: 10).") # Currently unused; clarify how to apply in the workflow.
parser$add_argument("--interaction_score_threshold", type = "numeric", default = 0.9, help = "Interaction score threshold for significance (default: 0.9)")
parser$add_argument("--width", type = "numeric", default = 800, help = "Width of the output plot in pixels (default: 800).")
parser$add_argument("--height", type = "numeric", default = 600, help = "Height of the output plot in pixels (default: 600).")
args <- parser$parse_args()

load(args$input_rda)
if (!exists("exp") || !exists("deg")) {
  stop("The 'exp' or 'deg' object does not exist in the provided RDA file.")
}

# 3. Filter up-/down-regulated miRNAs
pval_col <- if (args$is_use_padj) "adj.P.Val" else "P.Value"
k1 <- deg[[pval_col]] < args$pvalue_threshold & deg$logFC < -abs(args$log2fc_threshold)
k2 <- deg[[pval_col]] < args$pvalue_threshold & deg$logFC >  abs(args$log2fc_threshold)
deg$change <- ifelse(k1, "down", ifelse(k2, "up", "stable"))
deg <- deg %>% filter(change != "stable")

gene_up <- rownames(deg[deg$change == 'up', ])

# 2. Create STRINGdb object
string_db <- STRINGdb$new(
  version = "11.5", 
  species = 9606,
  score_threshold = args$interaction_score_threshold * 1000, 
  input_directory = ""
)

# Convert gene symbols to ENTREZID first
gene_up_df <- bitr(
  gene_up,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = org.Hs.eg.db,
  drop = TRUE
)
# gene_up_df contains two columns: SYMBOL and ENTREZID

# 3. Use map() to convert gene IDs to STRING IDs (STRINGdb supports multiple ID types).
gene <- gene_up %>% bitr(
  fromType = "SYMBOL", 
  toType = "ENTREZID", 
  OrgDb = "org.Hs.eg.db", 
  drop = T
)

data_mapped <- string_db$map(gene, "ENTREZID", removeUnmappedRows = TRUE) #ENTREZID 

# Visualization
hit <- data_mapped$STRING_id

png(filename = args$output_png, width = args$width, height = args$height, res = 300)
string_db$plot_network(hit[1:args$top_n])
dev.off()

# --- Save as PDF ---
if (!is.null(args$output_pdf) && nzchar(trimws(args$output_pdf))) {
  pdf(
    file = args$output_pdf,
    width = args$width / 300,
    height = args$height / 300
  )
  string_db$plot_network(hit[1:args$top_n])
  dev.off()
}

info <- string_db$get_interactions(hit)
write.table(info, file = args$output_csv, row.names = FALSE, quote = TRUE)
