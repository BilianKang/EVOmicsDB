# Example Data

This directory contains **minimal example data** for verifying that the EVOmicsDB analytical scripts run correctly. This dataset is a small subset derived from the manuscript use case, formatted for quick pipeline testing.

## Files

| File | Description |
|------|-------------|
| `demo_expression_matrix.tsv` | Log2-scaled expression matrix (subset of features and samples). |
| `demo_sample_metadata.tsv` | Sample group labels (Control / Cancer). |

## Usage

```bash
Rscript R/analysis/differential_analysis.R \
  --counts_file example_data/demo_expression_matrix.tsv \
  --output_rda results/demo_DEG.rda \
  --output_csv results/demo_filtered_DEG.csv
```

## Important

These data are **minimal example data for verifying script execution and input/output format only**. They are not intended for biological interpretation. For real analyses, download full datasets from [EVOmicsDB](https://EVOmicsDB.com).
